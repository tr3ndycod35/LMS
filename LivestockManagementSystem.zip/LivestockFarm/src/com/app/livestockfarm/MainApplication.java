/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm;

import com.app.livestockfarm.controllers.MainAppController;
import com.app.livestockfarm.controllers.DashboardPaneController;
import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @author Cherry
 */
public class MainApplication extends Application{
//    Application settings
//    private Locale defaultLocale = Locale.ENGLISH;
//    private String dateFormat;
//    private String currency;
//    private String language;
//    private Livestock defaultLivestock;
//    private int numberOfResults;

    public final static String DATABASE_URL = "jdbc:mysql://localhost:3306/livestock_farm";
    public final static String USER = "major";
    public final static String PASS = "v227ca";

    private Stage currentStage;

    /**
     * Overrides the superclass's start method. It is important to note that
     * this method is called automatically by the application runtime. The
     * primary stage of the application is initialized within this method and
     * displayed.
     *
     * @param primaryStage
     * @throws Exception
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        this.currentStage = primaryStage;
        this.currentStage.setResizable(false);
        gotoLogin();
        this.currentStage.show();

    }

    /**
     * Switches to the login page of the application.
     */
    public void gotoLogin() {
        Stage loginStage = new Stage();
        this.currentStage = loginStage;
        MainAppController mainAppController = (MainAppController) replaceContent("views/MainAppView.fxml", "Administrator Login");
        mainAppController.setApplication(this);
        this.currentStage.setResizable(false);
    }

    /**
     * Switches to the dashboard page of the application.
     */
    public void gotoDashboard() {
        Stage dashboardStage = new Stage();
        this.currentStage = dashboardStage;
        DashboardPaneController dashboardPane = (DashboardPaneController) replaceContent("views/DashboardView.fxml", "Dashboard");
        dashboardPane.setApplication(this);
        this.currentStage.show();
    }

    /**
     * This method performs a test using the username and password passed in by
     * connecting to the database through the JDBC driver and return either true
     * or false if the password is correct.
     *
     * @param username
     * @param password
     * @return boolean
     */
    public boolean isUserLoggedIn(String username, String password) {
        try {
            Connection connection = DriverManager.getConnection(DATABASE_URL, "major", "v227ca");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT password FROM user WHERE username='" + username + "';");
            resultSet.next();
            String result = resultSet.getString("password");
            if (result.equals(password)) {
                currentStage.hide();
                gotoDashboard();
                return true;
            }

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return false;
    }

    /**
     * This method parses the passed FXML file and returns an initializable; a
     * controller.
     *
     * @param fxml
     * @param title
     * @return Initializable
     * @throws Exception
     */
    public Initializable replaceContent(String fxml, String title) {
        FXMLLoader loader = null;

        Pane pane = null;
        try {
            loader = new FXMLLoader(MainApplication.class.getResource(fxml));
            pane = (Pane) loader.load();
        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        Scene scene = new Scene(pane);
        currentStage.setTitle(title);
        currentStage.setScene(scene);
        currentStage.sizeToScene();
        currentStage.setResizable(true);

        return (Initializable) loader.getController();
    }

    public MainApplication getInstance() {
        return this;
    }

    /**
     * The application's main method which launches the JavaFX thread. It calls
     * the launch method of the application and parses the arguments therein.
     *
     * @param args
     */
    public static void main(String[] args) {
        launch(args);
    }

}
