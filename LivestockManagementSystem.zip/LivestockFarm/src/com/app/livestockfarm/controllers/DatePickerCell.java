/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;

/**
 *
 * @author Cherry
 * @param <String>
 */
public class DatePickerCell<S, String> extends TableCell<S, String> {

    private String oldValue = null;
    private String newValue = null;

    public DatePickerCell() {
        super();
    }

    @Override
    public void startEdit() {
        super.startEdit();
        DatePicker datePicker = new DatePicker();
        datePicker.setValue(LocalDate.parse(oldValue.toString()));

        datePicker.setOnAction((actionEvent) -> {
            String value = (String) datePicker.getEditor().getText();
            SimpleDateFormat parsingPatternFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
            SimpleDateFormat formatPattern = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date dateObj = null;
            try {
                dateObj = parsingPatternFormat.parse(value.toString());
            } catch (ParseException ex) {
                Logger.getLogger(DatePickerCell.class.getName()).log(Level.SEVERE, null, ex);
            }
            String newValue = (String) formatPattern.format(dateObj);
            commitEdit(newValue);
        });
        setGraphic(datePicker);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
    }

    @Override
    public void cancelEdit() {
        super.cancelEdit();
        setContentDisplay(ContentDisplay.TEXT_ONLY);
    }

    @Override
    public void commitEdit(String value) {
        super.commitEdit(value);
        setText(value.toString());
        setContentDisplay(ContentDisplay.TEXT_ONLY);
    }

    @Override
    public void updateItem(String item, boolean empty) {
        super.updateItem(item, empty);
        if (empty || item == null) {
            setText(null);
            setGraphic(null);
        } else {
            oldValue = item;
//            System.out.println("OldItem: " + oldValue);
            setText(item.toString());
        }

    }

}
