/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class MessageDialogController implements Initializable {

    @FXML
    private ImageView imageLabel;
    @FXML
    private Label messageLabel;
    @FXML
    private Button dialogButton;
    @FXML
    private AnchorPane rootAnchorPane;
    @FXML
    private VBox vBox;
    @FXML
    private HBox hBox;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public Button getDialogButton(){
        return dialogButton;
    }

    void setImageOnLabel(String imageLocation) {
        imageLabel.setImage(new Image(getClass().getResource(imageLocation).toExternalForm())); 
    }

    void setMessageOnLabel(String message) {
        messageLabel.setText(message);
    }
    
}
