/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class RegisterSalesController implements Initializable {

    @FXML
    private Label errorLabel;
    @FXML
    private TextField transactionIDTextField;
    @FXML
    private ComboBox<String> livestockIDComboBox;
    @FXML
    private DatePicker dateSoldDatePicker;
    private TextField customerTextField;
    @FXML
    private TextField priceTextField;
     @FXML
    private ComboBox<String> customerIDComboBox;
    @FXML
    private TextArea remarksTextArea;
    @FXML
    private Button registerSalesButton;

    private Connection connection;
    private PreparedStatement statement;
    private ResultSet resultSet;
   

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        bootstrap();
    }

    private void bootstrap() {
        registerSalesButton.setGraphic(new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        registerSalesButton.setOnAction(event -> {
//            System.out.println(persistData());
            if (persistData()) {
                resetFields();
            }
        });
        dateSoldDatePicker.setValue(LocalDate.now());
        loadLivestockComboBoxWithOptions();
        loadCustomerComboBoxWithOptions();
    }

    private boolean persistData() {
        boolean done = false;
        if (validateInputFields()) {
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.prepareStatement("INSERT INTO `livestock_farm`.`sales` "
                        + "                              VALUES (?, ?, ?, ?, ?, ?);");
                int transactionID = Integer.valueOf(transactionIDTextField.getText());
                String livestockID = livestockIDComboBox.getSelectionModel().getSelectedItem().toString();
                String dateSold = dateSoldDatePicker.getValue().toString();
                String customer = customerIDComboBox.getSelectionModel().getSelectedItem().toString();
                double price = Double.valueOf(priceTextField.getText());
                String remarks = remarksTextArea.getText();
                statement.setInt(1, transactionID);
                statement.setString(2, livestockID);
                statement.setString(3, dateSold);
                statement.setString(4, customer);
                statement.setDouble(5, price);
                statement.setString(6, remarks);

                boolean result = statement.execute();
                if (result == false) {
                    displayOKDialog("Sales " + transactionID + " has been registered successfully!");
                    done = true;
                } else {
                    done = false;
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                //animateLabel(errorLabel, ex.getMessage());
            } catch (NumberFormatException ex) {
                animateLabel(errorLabel, "Both transaction id and price can only be number");
            }
        }
        return done;
    }

    private boolean validateInputFields() {
        boolean everythingSet;
        if (transactionIDTextField.getText() == null || transactionIDTextField.getText() == "" || transactionIDTextField.getText().isEmpty()
                || priceTextField.getText() == null || priceTextField.getText() == "" || priceTextField.getText().isEmpty()
                || remarksTextArea.getText() == null || remarksTextArea.getText() == "" || remarksTextArea.getText().isEmpty()) {
            animateLabel(errorLabel, "Fill empty fields!");
            everythingSet = false;
            return everythingSet;
        } else {
            everythingSet = true;
        }
        return everythingSet;
    }

    private void animateLabel(Label errorlabel, String message) {
        errorLabel.setText(message);
        errorLabel.setOpacity(1.0);
        FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
        transition1.setFromValue(1.0);
        transition1.setToValue(0.0);
        transition1.play();
    }

    private void resetFields() {
        transactionIDTextField.setText(null);
        livestockIDComboBox.getSelectionModel().clearSelection();
        dateSoldDatePicker.setValue(LocalDate.now());
        customerIDComboBox.getSelectionModel().clearSelection();
        priceTextField.setText(null);
        remarksTextArea.setText(null);
        remarksTextArea.setPromptText("Place your comment here");
    }

    private void displayOKDialog(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done!");
        alert.setContentText(message);
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.showAndWait();
    }

    private void loadLivestockComboBoxWithOptions() {
        ObservableList<String> livestockList = FXCollections.observableArrayList();
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT animal_id FROM livestock_table;");
            while (resultSet.next()) {
                livestockList.add(resultSet.getString("animal_id"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        livestockIDComboBox.setItems(livestockList);
    }

    private void loadCustomerComboBoxWithOptions() {
        ObservableList<String> customersList = FXCollections.observableArrayList();
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT id FROM customers;");
            while (resultSet.next()) {
                customersList.add(resultSet.getString("id"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        livestockIDComboBox.setItems(customersList);
    }

}
