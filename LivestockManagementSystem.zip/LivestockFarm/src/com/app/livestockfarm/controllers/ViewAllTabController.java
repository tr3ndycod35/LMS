/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.beans.Livestock;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.DefaultStringConverter;
import javafx.util.converter.DoubleStringConverter;

/**
 *
 * @author Cherry
 */
public class ViewAllTabController implements Initializable {

// Container widgets
    @FXML
    private VBox vBox;
    private HBox optionsHBox;
    private ScrollPane tabScrollPane;
    private TableView tableView;
    private ScrollPane tableScrollPane;

    // Table columns declaration
    private TableColumn<Livestock, String> animalIDColumn;
    private TableColumn<Livestock, String> animalTypeColumn;
    private TableColumn<Livestock, String> sourceColumn;
    private TableColumn<Livestock, String> birthDateColumn;
    private TableColumn<Livestock, String> sexColumn;
    private TableColumn<Livestock, Double> weightColumn;
    private TableColumn<Livestock, String> breedColumn;
    private TableColumn<Livestock, String> colorColumn;
    private TableColumn<Livestock, String> microchipInfoColumn;
    private TableColumn<Livestock, Double> marketValueColumn;
    private TableColumn<Livestock, String> campColumn;

// Database tools declaration
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
    private ResultSetMetaData data;

    @FXML
    private BorderPane borderPane;
    private Livestock livestock;

    public ViewAllTabController() {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            try {
                connection.close();
            } catch (SQLException ex1) {
                Logger.getLogger(ViewAllTabController.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }

        setTableProperties();
        initializeTableColumns();
        organizeLayouts();

        //vBox.getChildren().add(optionsHBox);
    }

    public VBox getvBox() {
        return vBox;
    }

    public HBox getOptionsHBox() {
        return optionsHBox;
    }

    public ScrollPane getTabScrollPane() {
        return tabScrollPane;
    }

    public TableView getTableView() {
        return tableView;
    }

    public ScrollPane getTableScrollPane() {
        return tableScrollPane;
    }

    public ObservableList<Livestock> getLivestockData() {
        ObservableList<Livestock> items = FXCollections.observableArrayList();
        try {

            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM livestock_farm.livestock_table;");

            data = resultSet.getMetaData();
            while (resultSet.next()) {
                String animalIDColumn = resultSet.getString("animal_id");
                String animalType = resultSet.getString("type");
                String source = resultSet.getString("source");
                String sex = resultSet.getString("sex");
                double weight = resultSet.getDouble("weight");
                Livestock livestock = new Livestock(animalIDColumn, animalType, source, sex, weight);
                livestock.setBirthDate(resultSet.getString("birth_date"));
                livestock.setBreed(resultSet.getString("breed"));
                livestock.setColor(resultSet.getString("color"));
                livestock.setMicrochipInfo(resultSet.getString("microchip_id"));
                livestock.setMarketValue(resultSet.getDouble("market_value"));
                livestock.setCamp(resultSet.getString("camp_id"));

                items.add(livestock);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return items;
    }

    public void initializeTableColumns() {
        animalIDColumn = new TableColumn<>("Animal ID");
        animalIDColumn.setCellValueFactory(new PropertyValueFactory<>("animalID"));
        animalIDColumn.setEditable(true);
        animalIDColumn.setOnEditCommit((TableColumn.CellEditEvent<Livestock, String> event) -> {
            String oldValue = event.getOldValue();
            String newValue = event.getNewValue();
            updateCell("animal_id", "animal_id", oldValue, newValue, event);
        });

        animalIDColumn.setCellFactory((TableColumn<Livestock, String> param) -> {
            TextFieldTableCell<Livestock, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        animalTypeColumn = new TableColumn<>("Type");
        animalTypeColumn.setCellValueFactory(new PropertyValueFactory<>("animalType"));
        animalTypeColumn.setCellFactory(tableColumn -> {
            ComboBoxTableCell<Livestock, String> cell = new ComboBoxTableCell<>("Cattle", "Goat", "Pig", "Rabbit");
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        animalTypeColumn.setOnEditCommit(event -> {
            updateCell("type", "animal_id", event.getOldValue(), event.getNewValue(), event);
        });

        sourceColumn = new TableColumn<>("Source");
        sourceColumn.setMinWidth(50);
        sourceColumn.setCellValueFactory(new PropertyValueFactory<>("source"));
        sourceColumn.setCellFactory(tableColumn -> {
            ComboBoxTableCell<Livestock, String> cell = new ComboBoxTableCell<>("Birth", "Purchased");
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        sourceColumn.setOnEditCommit(event -> {
            updateCell("source", "animal_id", event.getOldValue(), event.getNewValue(), event);
        });

        birthDateColumn = new TableColumn<>("Birth Date");
        PropertyValueFactory<Livestock, String> factory = new PropertyValueFactory<>("birthDate");
        birthDateColumn.setCellValueFactory(factory);
        birthDateColumn.setCellFactory(tableColumn -> {
            DatePickerCell<Livestock, String> cell = new DatePickerCell<>();
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        birthDateColumn.setOnEditCommit((event) -> {
            updateCell("birth_date", "animal_id", event.getOldValue(), event.getNewValue(), event);
        });

        sexColumn = new TableColumn<>("Sex");
        sexColumn.setCellValueFactory(new PropertyValueFactory<>("sex"));
        sexColumn.setCellFactory((tableColumn) -> {
            ComboBoxTableCell<Livestock, String> cell = new ComboBoxTableCell<>("Male", "Female");
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        sexColumn.setOnEditCommit((event) -> {
            updateCell("sex", "animal_id", event.getOldValue(), event.getNewValue(), event);
        });

        weightColumn = new TableColumn<>("Weight (Kg)");
        weightColumn.setCellValueFactory(new PropertyValueFactory<>("weight"));
        weightColumn.setCellFactory(tableColumn -> {
            TextFieldTableCell<Livestock, Double> cell = new TextFieldTableCell<>(new DoubleStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        weightColumn.setOnEditCommit(event -> {
            updateCell("weight", "animal_id", event.getOldValue().toString(), event.getNewValue().toString(), event);
        });

        breedColumn = new TableColumn<>("Breed");
        breedColumn.setCellValueFactory(new PropertyValueFactory<>("breed"));
        breedColumn.setCellFactory(tableColumn -> {
            TextFieldTableCell<Livestock, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        breedColumn.setOnEditCommit(event -> {
            updateCell("breed", "animal_id", event.getOldValue(), event.getNewValue(), event);
        });

        colorColumn = new TableColumn<>("Color");
        colorColumn.setCellValueFactory(new PropertyValueFactory<>("color"));
        colorColumn.setCellFactory(tableColumn -> {
            TextFieldTableCell<Livestock, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        colorColumn.setOnEditCommit(event -> {
            updateCell("color", "animal_id", event.getOldValue(), event.getNewValue(), event);
        });

        microchipInfoColumn = new TableColumn<>("Microchip Info");
        microchipInfoColumn.setMinWidth(50);
        microchipInfoColumn.setCellValueFactory(new PropertyValueFactory<>("microchipInfo"));
        microchipInfoColumn.setCellFactory(tableColumn -> {
            ObservableList<String> microchipsList = FXCollections.observableArrayList();
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.createStatement();
                resultSet = statement.executeQuery("SELECT microchip_id FROM microchip_data");
                while (resultSet.next()) {
                    microchipsList.add(resultSet.getString("microchip_id"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            ComboBoxTableCell<Livestock, String> cell = new ComboBoxTableCell<>(microchipsList);
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        microchipInfoColumn.setOnEditCommit(event -> {
            updateCell("microchip_id", "animal_id", event.getOldValue(), event.getNewValue(), event);
        });

        marketValueColumn = new TableColumn<>("Market Value");
        marketValueColumn.setCellValueFactory(new PropertyValueFactory<>("marketValue"));
        marketValueColumn.setCellFactory(tableColumn -> {
            DoubleFieldTableCell<Livestock, Double> cell = new DoubleFieldTableCell<Livestock, Double>();
            cell.setConverter(new DoubleStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        marketValueColumn.setOnEditCommit(event -> {
            updateCell("market_value", "animal_id", event.getOldValue().toString(), event.getNewValue().toString(), event);
        });

        campColumn = new TableColumn<>("Camp");
        campColumn.setCellValueFactory(new PropertyValueFactory<>("camp"));
        campColumn.setCellFactory(tableColumn -> {
            // Populate list of camp from database and add each camp to an ArrayList object.
            ObservableList<String> campsList = FXCollections.observableArrayList();
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.createStatement();
                resultSet = statement.executeQuery("SELECT camp_id FROM camp_data");
                while (resultSet.next()) {
                    campsList.add(resultSet.getString("camp_id"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            // Set the gotten list as the model for this renderer.
            ComboBoxTableCell<Livestock, String> cell = new ComboBoxTableCell<>(campsList);
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        campColumn.setOnEditCommit(event -> {
            updateCell("camp_id", "animal_id", event.getOldValue(), event.getNewValue(), event);
        });

        tableView.getColumns().addAll(animalIDColumn, animalTypeColumn, sourceColumn,
                birthDateColumn, sexColumn, weightColumn, breedColumn, colorColumn,
                microchipInfoColumn, marketValueColumn, campColumn);
    }

    private void displayAddLivestockStage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("views/AddLivestockView.fxml"));
            Pane pane = (Pane) loader.load();
            Scene addLivestockScene = new Scene(pane);
            Stage addLivestockStage = new Stage();
            addLivestockStage.initModality(Modality.APPLICATION_MODAL);
            addLivestockStage.setResizable(false);
            addLivestockStage.setTitle("Add New Livestock");
            addLivestockStage.setScene(addLivestockScene);
            addLivestockStage.sizeToScene();
            addLivestockStage.show();
        } catch (MalformedURLException ex) {
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void updateView(ResultSet resultSet, LivestockDetailsController controller, Stage stage) throws SQLException {
        stage.setTitle("Livestock: " + livestock.toString());
        controller.getAnimalIDTextField().setText(resultSet.getString("animal_id"));
        controller.getAnimalTypeComboBox().getSelectionModel().select(resultSet.getString("type"));
        controller.getAnimalSourceComboBox().getSelectionModel().select(resultSet.getString("source"));
        controller.getDobDatePicker().setValue(LocalDate.parse(resultSet.getDate("birth_date").toString()));
        controller.getSexComboBox().getSelectionModel().select(resultSet.getString("sex"));
        controller.getWeightTextField().setText(resultSet.getString("weight"));
        controller.getBreedTextField().setText(resultSet.getString("breed"));
        controller.getColorTextField().setText(resultSet.getString("color"));
        controller.getSireIDTextField().setText(resultSet.getString("sire_id"));
        controller.getDamIDTextField().setText(resultSet.getString("dam_id"));
        controller.getMicrochipTextField().setText(resultSet.getString("microchip_id"));
        controller.getBookValueTextField().setText(resultSet.getString("book_value"));
        controller.getMarketValueTextField().setText(resultSet.getString("market_value"));
        controller.getCampIDTextField().setText(resultSet.getString("camp_id"));

        controller.getDatePurchasePicker().setValue(LocalDate.parse(resultSet.getDate("birth_date").toString()));
        controller.getSellerTextField().setText("");

        controller.getCancelButton().setOnAction((closeEvent) -> {
            stage.close();
        });
    }

    private void setTableProperties() {
        tableView = new TableView();
        tableView.setItems(getLivestockData());
        tableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        tableView.setTableMenuButtonVisible(true);
        tableView.setPrefWidth(1100);
        tableView.setPrefHeight(700);
        tableView.setEditable(true);
        attachContextMenu(tableView);

    }

    private void attachContextMenu(TableView tableView) {
        ContextMenu tableContextMenu = new ContextMenu();
        MenuItem refreshMenuItem = new MenuItem("Refresh Data", new ImageView(getClass().getResource("images/buttons/refresh.png").toExternalForm()));
        refreshMenuItem.setOnAction((e) -> {
            tableView.setItems(getLivestockData());
        });
        MenuItem addMenuItem = new MenuItem("Add New Livestock", new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        addMenuItem.setOnAction((e) -> {
            displayAddLivestockStage();
        });

        MenuItem viewMenuItem = new MenuItem("View Detailed Information", new ImageView(getClass().getResource("images/buttons/detail_view.png").toExternalForm()));
        MenuItem editMenuItem = new MenuItem("Edit Livestock", new ImageView(getClass().getResource("images/buttons/edit.png").toExternalForm()));
        MenuItem removeMenuItem = new MenuItem("Remove Livestock", new ImageView(getClass().getResource("images/buttons/remove.png").toExternalForm()));
        removeMenuItem.setOnAction(eventHandler -> {
            removeLivestock();
        });
        MenuItem trackGrowthMenuItem = new MenuItem("Track Growth", new ImageView(getClass().getResource("images/buttons/growth.png").toExternalForm()));

        tableContextMenu.getItems().addAll(refreshMenuItem, addMenuItem, viewMenuItem, editMenuItem, trackGrowthMenuItem, removeMenuItem);

        tableView.setContextMenu(tableContextMenu);

    }

    private void displayDetailedInformationStage() {
        Stage stage = new Stage();
        try {
            livestock = (Livestock) tableView.getSelectionModel().getSelectedItem();
            tableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM livestock_farm.livestock_table WHERE animal_id ='" + livestock.toString() + "';");
            resultSet.next();

            FXMLLoader loader = new FXMLLoader(new URL(getClass().getResource("views/LivestockDetailView.fxml").toExternalForm()));
            Pane pane = (Pane) loader.load();
            LivestockDetailsController controller = loader.getController();
            controller.getPrevItemButton().setOnAction((prevEvent) -> {
                tableView.getSelectionModel().selectPrevious();
                livestock = (Livestock) tableView.getSelectionModel().getSelectedItem();
                try {
                    resultSet = statement.executeQuery("SELECT * FROM livestock_farm.livestock_table WHERE animal_id ='" + livestock.toString() + "';");
                    resultSet.next();
                    updateView(resultSet, controller, stage);
                } catch (SQLException sQLException) {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setTitle("Illegal Operation");
                    errorAlert.setContentText("This action can not be performed due to the fact that the data model has been modified. Please refresh the data in the table and try again.");
                    errorAlert.initModality(Modality.APPLICATION_MODAL);
                    errorAlert.showAndWait();
                }
            });
            controller.getNextItemButton().setOnAction((nextEvent) -> {
                tableView.getSelectionModel().selectNext();
                livestock = (Livestock) tableView.getSelectionModel().getSelectedItem();
                try {
                    resultSet = statement.executeQuery("SELECT * FROM livestock_farm.livestock_table WHERE animal_id ='" + livestock.toString() + "';");
                    resultSet.next();
                    updateView(resultSet, controller, stage);
                } catch (SQLException sQLException) {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setTitle("Illegal Operation");
                    errorAlert.setContentText("This action can not be performed due to the fact that the data model has been modified. Please refresh the data in the table and try again.");
                    errorAlert.initModality(Modality.APPLICATION_MODAL);
                    errorAlert.showAndWait();
                }
            });

            try {
                updateView(resultSet, controller, stage);
                Scene scene = new Scene(pane);
                stage.setScene(scene);
                stage.setResizable(false);
                stage.setTitle("Livestock: " + livestock.toString());
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.showAndWait();
            } catch (SQLException sQLException) {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Illegal Operation");
                errorAlert.setContentText("This action can not be performed due to the fact that the data model has been modified. Please refresh the data in the table and try again.");
                errorAlert.initModality(Modality.APPLICATION_MODAL);
                errorAlert.showAndWait();
            }

        } catch (NullPointerException ex) {
            displayInformationDialog();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (SQLException sQLException) {
            sQLException.printStackTrace();
        } catch (NoSuchElementException ex) {

        }
    }

    private void organizeLayouts() {
        tableScrollPane = new ScrollPane(tableView);
        //tableScrollPane.setPrefViewportWidth();
        vBox.getChildren().add(tableScrollPane);
        borderPane.setCenter(vBox);

        optionsHBox = new HBox();
        borderPane.setBottom(optionsHBox);
        optionsHBox.setPadding(new Insets(10));
        optionsHBox.setSpacing(10);
        optionsHBox.setAlignment(Pos.CENTER);
        createButtonsForHBox();
    }

    private void createButtonsForHBox() {
        Button detailedButton = new Button("View Detailed Information", new ImageView(getClass().getResource("images/buttons/detail_view.png").toExternalForm()));
        detailedButton.setOnAction((ActionEvent e) -> {
            displayDetailedInformationStage();
        });
        Button editButton = new Button("Edit Livestock Data", new ImageView(getClass().getResource("images/buttons/edit.png").toExternalForm()));

        Button addButton = new Button("Add Livestock Data", new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));

        addButton.setOnAction((e) -> {
            displayAddLivestockStage();
        });
        Button deleteButton = new Button("Remove Livestock Data", new ImageView(getClass().getResource("images/buttons/remove.png").toExternalForm()));
        optionsHBox.getChildren().addAll(detailedButton, addButton, deleteButton);
    }

    private void updateCell(String dbColumnName, String primaryKey, String oldValue, String newValue, TableColumn.CellEditEvent event) {
        try {
            statement = connection.createStatement();
            int result = statement.executeUpdate("UPDATE `livestock_farm`.`livestock_table` SET `" + dbColumnName + "` ='" + newValue + "' WHERE (`" + primaryKey + "` =\"" + animalIDColumn.getCellData(event.getTablePosition().getRow()) + "\");");
            tableView.setItems(getLivestockData());
            //tableView.getSelectionModel().select(event.getTablePosition().getRow());
        } catch (MySQLSyntaxErrorException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Please refactor the data to exclude special characters.");
            alert.initModality(Modality.APPLICATION_MODAL);
//            Platform.runLater(() -> {
//                tableView.refresh();
            tableView.getSelectionModel().select(event.getTablePosition().getRow());
            tableView.refresh();
//            });
            alert.showAndWait();
        } catch (MySQLIntegrityConstraintViolationException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("The microchip identifier you selected has been used for another livestock.");
            alert.initModality(Modality.APPLICATION_MODAL);
            Platform.runLater(() -> {
                tableView.refresh();
                tableView.getSelectionModel().select(event.getTablePosition().getRow());
            });
            alert.showAndWait();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    private void removeLivestock() {
        String key = getTableView().getSelectionModel().getSelectedItem().toString();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setContentText("Are you sure you want to remove this livestock");
        alert.initModality(Modality.APPLICATION_MODAL);
        Optional<ButtonType> option = alert.showAndWait();
        if (option.isPresent() && option.get() == ButtonType.OK) {
            try {
                boolean result = statement.execute("DELETE FROM livestock_table where animal_id = '" + key + "';");
                tableView.setItems(getLivestockData());
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } else {
            alert.close();
        }

    }

    private void displayInformationDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "No Livestock has been selected yet!", ButtonType.OK);
        alert.setTitle("Information!");
        Optional<ButtonType> result = alert.showAndWait();
        alert.setOnCloseRequest(event -> alert.close());
        if (result.get() != ButtonType.OK) {
            alert.close();
        }
    }

    class DoubleFieldTableCell<Livestock, Object> extends TextFieldTableCell<Livestock, Object> {

        @Override
        public void commitEdit(Object value) {
            if (Double.valueOf(String.valueOf(value)).isNaN()) {
                System.out.println("Fuck you! it's not a number");
            } else {
                super.commitEdit(value);
            }
        }
    }

}
