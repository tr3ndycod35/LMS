/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.beans.Customer;
import com.mysql.jdbc.MysqlDataTruncation;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class UpdateCustomerPhotoViewController implements Initializable {

    @FXML
    private ImageView imageView;
    @FXML
    private TextField uploadTextField;
    @FXML
    private Button uploadButton;
    @FXML
    private Button updateButton;
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        updateButton.setGraphic(new ImageView(getClass().getResource("images/buttons/update_user.png").toExternalForm()));
        uploadButton.setGraphic(new ImageView(getClass().getResource("images/buttons/upload.png").toExternalForm()));
    }

    public ImageView getImageView() {
        return imageView;
    }

    public TextField getUploadTextField() {
        return uploadTextField;
    }

    public Button getUploadButton() {
        return uploadButton;
    }

    public Button getUpdateButton() {
        return updateButton;
    }

    protected void loadImageOfCustomer(Customer customer) {
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT photo FROM customers WHERE id=\"" + customer + "\";");
            resultSet.next();
            InputStream inputStream = resultSet.getBinaryStream("photo");
            Image image = new Image(inputStream, imageView.getFitWidth(), imageView.getFitHeight(), true, true);
            imageView.setImage(image);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    protected boolean updateCustomerPhoto(Customer customer) {
        boolean result = true;
        try {
            String photoFileName = uploadTextField.getText();
            File imageFile = new File(photoFileName);
            FileInputStream fis = new FileInputStream(imageFile);
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            preparedStatement = connection.prepareStatement("UPDATE `livestock_farm`.`customers` SET `photo` = ? WHERE (`id` = ?);");
            preparedStatement.setBinaryStream(1, fis);
            preparedStatement.setString(2, customer.getCustomerID());
            result = preparedStatement.execute();
            
        } catch (MysqlDataTruncation ex) {
            displayInformationDialog("The size of the selected image is too much. Please select another file or compress the previously selected file and then try again");
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return result;
    }

    protected boolean validateSelectedFile(File file) {
        boolean validImageFile = false;
        if (file.isFile()) {
            if (file.getName().endsWith(".png") || file.getName().endsWith(".jpeg") || file.getName().endsWith(".jpg")) {
                validImageFile = true;
                return validImageFile;
            }
        } else {
            validImageFile = false;
            return validImageFile;
        }
        return validImageFile;
    }

    private void displayInformationDialog(String message) {
        try {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
            alert.setTitle("Information!");
            Optional<ButtonType> result = alert.showAndWait();
            alert.setOnCloseRequest(event -> alert.close());
            if (result.get() != ButtonType.OK) {
                alert.close();
            }
        } catch (NoSuchElementException ex) {
        }
    }
}
