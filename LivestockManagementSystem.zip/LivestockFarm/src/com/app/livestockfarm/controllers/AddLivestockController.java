/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.util.Duration;

/**
 *
 * @author Cherry
 */
public class AddLivestockController implements Initializable {

    @FXML
    private TextField idTextField;
    @FXML
    private ComboBox<Object> animalTypeComboBox;
    @FXML
    private DatePicker dobDatePicker;
    @FXML
    private ComboBox<Object> sexComboBox;
    @FXML
    private TextField breedTextField;
    @FXML
    private TextField colortextField;
    @FXML
    private TextField bookValueTextField;
    @FXML
    private ImageView idErrorLabel;
    @FXML
    private Button addLivestockButton;
    @FXML
    private Label errorLabel;
    @FXML
    private TextField weightTextField;
    @FXML
    private ImageView marketErrorLabel;
    @FXML
    private ImageView weightErrorLabel;
    @FXML
    private ImageView dateErrorLabel;
    @FXML
    private ComboBox<String> sourceComboBox;

    public void addLiveStockData() {

    }

    public void populateComboBoxesWithData() {
        animalTypeComboBox.getItems().addAll("Cattle", "Goat", "Pig", "Rabbit");
        animalTypeComboBox.getSelectionModel().selectFirst();
        sourceComboBox.getItems().addAll("Birth", "Purchased");
        sourceComboBox.getSelectionModel().selectFirst();
        sexComboBox.getItems().addAll("Male", "Female");
        sexComboBox.getSelectionModel().selectFirst();
        
    }

    public void animateErrorLabel() {
        FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
        transition1.setFromValue(1.0);
        transition1.setToValue(0.0);
        transition1.play();

        FadeTransition transition2 = new FadeTransition(Duration.seconds(3), idErrorLabel);
        transition2.setFromValue(1.0);
        transition2.setToValue(0.0);
        transition2.play();
    }

    public String getLivestockID() {
        if (idTextField.getText().isEmpty()) {
            errorLabel.setText("Id must not be empty");
            animateErrorLabel();
            idErrorLabel.setOpacity(1.0);

        } else if (idTextField.getText().contains(" ")) {
            errorLabel.setText("ID must not contiain space");
            animateErrorLabel();
        } else {
            return idTextField.getText();
        }
        return null;
    }

    public double validateBookValue(String value) {
        double price = 0;
        if (value.isEmpty()) {
            return 0.0;
        }
        try {
            price = Double.valueOf(value);
        } catch (NumberFormatException numberFormatException) {
            errorLabel.setText("Market value must be number");
            FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
            transition1.setFromValue(1.0);
            transition1.setToValue(0.0);
            transition1.play();

            FadeTransition transition2 = new FadeTransition(Duration.seconds(3), marketErrorLabel);
            marketErrorLabel.setOpacity(1.0);
            marketErrorLabel.setVisible(true);
            transition2.setFromValue(1.0);
            transition2.setToValue(0.0);
            transition2.play();
        }
        return price;
    }

    public double validateWeight(String value) {
        double weight = 0;
        if (value.isEmpty()) {
            return 0;
        }
        try {
            weight = Double.valueOf(value);
        } catch (NumberFormatException numberFormatException) {
            errorLabel.setText("Value of weight must be number");
            FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
            transition1.setFromValue(1.0);
            transition1.setToValue(0.0);
            transition1.play();

            FadeTransition transition2 = new FadeTransition(Duration.seconds(3), weightErrorLabel);
            transition2.setFromValue(1.0);
            transition2.setToValue(0.0);
            transition2.play();
        }

        return weight;
    }

    public String validateDate(String value) {
        if (value.isEmpty()) {
            return "";
        }
        return dobDatePicker.getValue().toString();

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
//        try {
        populateComboBoxesWithData();
        addLivestockButton.setGraphic(new ImageView(new Image(getClass().getResource("images/buttons/add.png").toExternalForm())));
        addLivestockButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                String id = getLivestockID();
                String type = animalTypeComboBox.getSelectionModel().getSelectedItem().toString();
                String source = sourceComboBox.getSelectionModel().getSelectedItem().toString();
                LocalDate dob = dobDatePicker.getValue();
                String sex = sexComboBox.getSelectionModel().getSelectedItem().toString();
                double weight = validateWeight(weightTextField.getText());
                String breed = breedTextField.getText();
                String color = colortextField.getText();
                double bookValue = validateBookValue(bookValueTextField.getText());

                try {
                    Connection connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                    PreparedStatement statement = connection.prepareStatement("INSERT INTO `livestock_farm`.`livestock_table` (`animal_id`, `type`, `source`, `birth_date`, `sex`, `weight`, `breed`, `color`, `book_value`)"
                            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?);");
                    statement.setString(1, id);
                    statement.setString(2, type);
                    statement.setString(3, source);
                    statement.setString(4, dob.toString());
                    statement.setString(5, sex);
                    statement.setDouble(6, weight);
                    statement.setString(7, breed);
                    statement.setString(8, color);
                    statement.setDouble(9, bookValue);
                    statement.execute();

                    Alert alert = new Alert(Alert.AlertType.NONE, "Livestock has been added successfully", ButtonType.OK);
                    alert.initModality(Modality.APPLICATION_MODAL);
                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.isPresent() && result.get() == ButtonType.OK) {
                        alert.close();
                    }

                    // Clear Form Fields
                    clearFields();

                } catch (SQLException exception) {
                    exception.printStackTrace();
                } catch (NullPointerException ex) {
                    errorLabel.setText("Make sure you fill all fields");
                    FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
                    transition1.setFromValue(1.0);
                    transition1.setToValue(0.0);
                    transition1.play();
                    
                    FadeTransition transition2 = new FadeTransition(Duration.seconds(3), dateErrorLabel);
                    dateErrorLabel.setOpacity(1.0);
                    transition2.setFromValue(1.0);
                    transition2.setToValue(0.0);
                    transition2.play();
                }
            }
        });
    }

    private void clearFields() {
        idTextField.clear();
        animalTypeComboBox.setValue("Cattle");
        dobDatePicker.setValue(null);
        sexComboBox.setValue("Male");
        weightTextField.clear();
        breedTextField.clear();
        colortextField.clear();
        bookValueTextField.clear();
    }

}
