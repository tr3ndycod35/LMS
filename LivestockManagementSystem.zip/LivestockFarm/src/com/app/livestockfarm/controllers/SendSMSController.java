/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;

import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Paint;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class SendSMSController implements Initializable {

    @FXML
    private Tab sendMessageTab;
    @FXML
    private Button sendSMSButton;
    @FXML
    private TextField fromTextField;
    @FXML
    private TextField toTextField;
    @FXML
    private TextArea messageTextArea;
    @FXML
    private Tab consoleTab;
    @FXML
    private TextArea consoleTextArea;
    @FXML
    private Tab settingsTab;
    @FXML
    private TextField usernameTextField;
    @FXML
    private TextField apiKeyTextField;
    @FXML
    private Button saveConfigurationButton;

    private Connection connection;
    private PreparedStatement statement;
    @FXML
    private MenuButton optionsMenuButton;
    @FXML
    private Button uploadContactButton;
    @FXML
    private Button allCustomersButtons;
    @FXML
    private MenuItem refreshSmsCreditMenuItem;
    @FXML
    private MenuItem rechargeSmsCreditMenuItem;
    @FXML
    private Label creditLabel;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            try {
                connection.close();
            } catch (SQLException ex1) {
                Logger.getLogger(ViewAllTabController.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }
        loadSmsConfigurations();
        configureSendButton();
        configureSaveConfigurationsButton();
        configureUploadContactsButton();
        configureAllCustomersButton();
        configureMenuItems();
//        displayCreditOnLabel();
    }

    private void loadSmsConfigurations() {
        try {
            statement = connection.prepareStatement("SELECT * FROM sms_setting");
            ResultSet resultSet = statement.executeQuery();
            resultSet.next();
            usernameTextField.setText(resultSet.getString("username"));
            apiKeyTextField.setText(resultSet.getString("api_key"));

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void configureSendButton() {
        sendSMSButton.setGraphic(new ImageView(getClass().getResource("images/buttons/send_message.png").toExternalForm()));
        sendSMSButton.setOnAction(handler -> {
            System.out.println("Handle sending of text messages here.");
        });
    }

    private void configureSaveConfigurationsButton() {
        saveConfigurationButton.setGraphic(new ImageView(getClass().getResource("images/buttons/save.png").toExternalForm()));
        saveConfigurationButton.setOnAction(handler -> {
            try {
                String username = usernameTextField.getText();
                String apiKey = apiKeyTextField.getText();

                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.prepareStatement("UPDATE `livestock_farm`.`sms_setting`"
                        + "                                                  SET `username`     = ?,"
                        + "                                                      `api_key`      = ?"
                        + "                                                  WHERE (`username`  = ?);");
                statement.setString(1, usernameTextField.getText());
                statement.setString(2, apiKeyTextField.getText());
                statement.setString(3, username);

                System.out.println("Username: " + username + ", API Key: " + apiKey);

                boolean haveResults = statement.execute();
                System.out.println("Result: " + haveResults);
                if (!haveResults) {
                    displayInformationDialog("Configuration Saved");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });
    }

    private void displayInformationDialog(String message) {
        try {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
            alert.setTitle("Information!");
            Optional<ButtonType> result = alert.showAndWait();
            alert.setOnCloseRequest(event -> alert.close());
            if (result.get() != ButtonType.OK) {
                alert.close();
            }
        } catch (NoSuchElementException ex) {
        }
    }

    private void configureUploadContactsButton() {
        uploadContactButton.setGraphic(new ImageView(getClass().getResource("images/buttons/upload.png").toExternalForm()));
    }

    private void configureAllCustomersButton() {
        allCustomersButtons.setGraphic(new ImageView(getClass().getResource("images/buttons/customers.png").toExternalForm()));
    }

    private void configureMenuItems() {
        rechargeSmsCreditMenuItem.setOnAction(handler -> {
            try {
                Desktop.getDesktop().browse(new URI("https://www.ebulksms.com/payments"));
            } catch (IOException ex) {
                ex.printStackTrace();
            } catch (URISyntaxException ex) {
                ex.printStackTrace();
            }
        });

        refreshSmsCreditMenuItem.setOnAction(handler -> {
            try {
                URL url = new URL("http://api.ebulksms.com:8080/balance/livestock.major@gmail.com/8b826a1f83ce3613984db0b1eb89b7818b338452");
                HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
                httpConnection.setDoInput(true);
                httpConnection.setDoOutput(true);
                httpConnection.setRequestMethod("POST");
                httpConnection.setRequestProperty("Content-Type", "text/css");

                httpConnection.connect();

                String result = "";
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpConnection.getInputStream()));
                String line = bufferedReader.readLine();
                while (line != null) {
                    result = line + "\n";
                    line = bufferedReader.readLine();
                }

                double value = Double.parseDouble(result);
                if (value < 10) {
                    creditLabel.setTextFill(Paint.valueOf("Red"));
                }
                creditLabel.setText(String.valueOf(value));

            } catch (MalformedURLException ex) {
//                ex.printStackTrace();
                displayInformationDialog("Invalid URL ");
            } catch (IOException ex) {
//                ex.printStackTrace();
                displayInformationDialog("Error connecting to web service, please check your Internet connection");
            }

        });
    }
    
    private void displayCreditOnLabel() {
         try {
                URL url = new URL("http://api.ebulksms.com:8080/balance/livestock.major@gmail.com/8b826a1f83ce3613984db0b1eb89b7818b338452");
                HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
                httpConnection.setDoInput(true);
                httpConnection.setDoOutput(true);
                httpConnection.setRequestMethod("POST");
                httpConnection.setRequestProperty("Content-Type", "text/css");

                httpConnection.connect();

                String result = "";
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpConnection.getInputStream()));
                String line = bufferedReader.readLine();
                while (line != null) {
                    result = line + "\n";
                    line = bufferedReader.readLine();
                }

                double value = Double.parseDouble(result);
                if (value < 10) {
                    creditLabel.setTextFill(Paint.valueOf("Red"));
                }
                creditLabel.setText(String.valueOf(value));

            } catch (MalformedURLException ex) {
//                ex.printStackTrace();
                displayInformationDialog("Invalid URL ");
            } catch (IOException ex) {
//                ex.printStackTrace();
                displayInformationDialog("Error connecting to web service, please check your Internet connection");
            }

    }

}
