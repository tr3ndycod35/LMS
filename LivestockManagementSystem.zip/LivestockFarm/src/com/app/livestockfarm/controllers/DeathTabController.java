/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.beans.Death;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.DefaultStringConverter;
import javafx.util.converter.IntegerStringConverter;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class DeathTabController implements Initializable {

    @FXML
    private ScrollPane tableScrollPane;
    @FXML
    private TableColumn<Death, Integer> snColumn;
    @FXML
    private TableColumn<Death, String> livestockColumn;
    @FXML
    private TableColumn<Death, String> dateColumn;
    @FXML
    private TableColumn<Death, String> causeColumn;
    @FXML
    private TableColumn<Death, String> remarksColumn;
    @FXML
    private TableView<Death> deathTable;

    // Database related fields
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    // Context Menu related fields
    private ContextMenu contextMenu;
    private MenuItem registerDeathContextMenu;
    private MenuItem removeDeathContextMenu;
    private MenuItem refreshDeathContextMenu;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        deathTable.prefHeightProperty().bind(tableScrollPane.heightProperty());
//        deathTable.prefWidthProperty().bind(tableScrollPane.widthProperty());
        setTableProperties();
        populateTableWithData();
    }

    private void populateTableWithData() {

        ObservableList<Death> items = FXCollections.observableArrayList();
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM deaths;");

            while (resultSet.next()) {
                int serialNumber = resultSet.getInt("serial_number");
                String animalID = resultSet.getString("livestock");
                String dod = resultSet.getString("date_of_death");
                String cause = resultSet.getString("cause_of_death");
                String remark = resultSet.getString("remarks");
                Death deathObject = new Death(serialNumber, animalID, dod, cause, remark);
                items.add(deathObject);
            }
            deathTable.setItems(items);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void setTableProperties() {
        deathTable.setEditable(true);
        configureTableColumns();
        addContextMenu();
    }

    private void configureTableColumns() {
        setCellValueFactories();
        setCellFactories();
        attachEventsToTableColumns();
    }

    private void setCellValueFactories() {
        snColumn.setCellValueFactory(new PropertyValueFactory<>("serialNumber"));
        livestockColumn.setCellValueFactory(new PropertyValueFactory<>("livestock"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("dateOfDeath"));
        causeColumn.setCellValueFactory(new PropertyValueFactory<>("causeOfDeath"));
        remarksColumn.setCellValueFactory(new PropertyValueFactory<>("remarks"));
    }

    private void setCellFactories() {
        snColumn.setCellFactory(value -> {
            TextFieldTableCell<Death, Integer> cell = new TextFieldTableCell<>(new IntegerStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        livestockColumn.setCellFactory(value -> {
            ObservableList<String> livestockList = FXCollections.observableArrayList();
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.createStatement();
                resultSet = statement.executeQuery("SELECT animal_id FROM livestock_table;");
                while (resultSet.next()) {
                    livestockList.add(resultSet.getString("animal_id"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            ComboBoxTableCell<Death, String> cell = new ComboBoxTableCell<>(livestockList);
            cell.setConverter(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        dateColumn.setCellFactory(value -> {
            DatePickerCell<Death, String> cell = new DatePickerCell<>();
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        causeColumn.setCellFactory(value -> {
            TextFieldTableCell<Death, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        remarksColumn.setCellFactory(value -> {
            TextFieldTableCell<Death, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
    }

    private void attachEventsToTableColumns() {
        snColumn.setOnEditCommit(eventHandler -> {
            updateCell("serial_number", "serial_number", eventHandler.getOldValue().toString(), eventHandler.getNewValue().toString(), eventHandler);
        });
        livestockColumn.setOnEditCommit(eventHandler -> {
            updateCell("livestock", "serial_number", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        dateColumn.setOnEditCommit(eventHandler -> {
            updateCell("date_of_death", "serial_number", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        causeColumn.setOnEditCommit(eventHandler -> {
            updateCell("cause_of_death", "serial_number", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        remarksColumn.setOnEditCommit(eventHandler -> {
            updateCell("remarks", "serial_number", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
    }

    private void updateCell(String dbColumnName, String primaryKey, String oldValue, String newValue, TableColumn.CellEditEvent event) {
        try {
            statement = connection.createStatement();
            int result = statement.executeUpdate("UPDATE `livestock_farm`.`deaths` SET `" + dbColumnName + "` ='" + newValue + "' WHERE (`" + primaryKey + "` =\"" + snColumn.getCellData(event.getTablePosition().getRow()) + "\");");
            populateTableWithData();
            //tableView.getSelectionModel().select(event.getTablePosition().getRow());
        } catch (MySQLSyntaxErrorException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Please refactor the data to exclude special characters.");
            alert.initModality(Modality.APPLICATION_MODAL);
            deathTable.getSelectionModel().select(event.getTablePosition().getRow());
            deathTable.refresh();
            alert.showAndWait();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void addContextMenu() {
        contextMenu = new ContextMenu();

        registerDeathContextMenu = new MenuItem("Register Livestock Death", new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        registerDeathContextMenu.setOnAction(event -> {
            displayRegisterDiseaseView();
        });

        removeDeathContextMenu = new MenuItem("Delete Death Record", new ImageView(getClass().getResource("images/buttons/remove.png").toExternalForm()));
        removeDeathContextMenu.setOnAction(eventHandler -> {

            Death deathObject = deathTable.getSelectionModel().getSelectedItem();
            try {
                statement.execute("DELETE FROM deaths WHERE serial_number = '" + deathObject.toString() + "';");
                populateTableWithData();
            } catch (SQLException ex) {
                ex.printStackTrace();
                displayInformationDialog();
            } catch (NullPointerException ex) {
                displayInformationDialog();
            }
        });

        refreshDeathContextMenu = new MenuItem("Refresh", new ImageView(getClass().getResource("images/buttons/refresh.png").toExternalForm()));
        refreshDeathContextMenu.setOnAction(eventHandler -> {
            populateTableWithData();
        });
        contextMenu.getItems().addAll(refreshDeathContextMenu, registerDeathContextMenu, removeDeathContextMenu);
        deathTable.setContextMenu(contextMenu);
    }

    private void displayRegisterDiseaseView() {
        try {
            //Load the AddMicrochipView Stage
            FXMLLoader loader = new FXMLLoader(new URL(getClass().getResource("views/RegisterDeath.fxml").toExternalForm()));
            AddMicrochipViewController controller = loader.getController();
            Pane root = (Pane) loader.load();
            Stage stage = new Stage();
            stage.setTitle("Register Livestock Death");
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.sizeToScene();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();

        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {

        }
    }

    private void displayInformationDialog() {
        try {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No disease record has been selected yet!", ButtonType.OK);
            alert.setTitle("Information!");
            Optional<ButtonType> result = alert.showAndWait();
            alert.setOnCloseRequest(event -> alert.close());
            if (result.get() != ButtonType.OK) {
                alert.close();
            }
        } catch (NoSuchElementException ex) {}
    }
    
}
