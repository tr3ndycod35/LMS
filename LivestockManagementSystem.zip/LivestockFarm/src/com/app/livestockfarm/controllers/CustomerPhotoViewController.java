/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.beans.Customer;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class CustomerPhotoViewController implements Initializable {

    @FXML
    private ImageView imageView;
    @FXML
    private Label nameLabel;
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    protected void loadImageOfCustomer(Customer customer) {
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT photo FROM customers WHERE id=\"" + customer + "\";");
            resultSet.next();
            InputStream inputStream = resultSet.getBinaryStream("photo");
            Image image = new Image(inputStream, imageView.getFitWidth(), imageView.getFitHeight(), true, true);
            nameLabel.setText(customer.getFirstName() + " " + customer.getLastName());
            imageView.setImage(image);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

}
