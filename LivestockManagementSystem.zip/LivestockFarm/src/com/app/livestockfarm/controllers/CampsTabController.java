/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.beans.Camp;
import com.app.livestockfarm.beans.Microchip;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.DefaultStringConverter;
import javafx.util.converter.IntegerStringConverter;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class CampsTabController implements Initializable {

    @FXML
    private ScrollPane tableScrollPane;

    @FXML
    private TableView<Camp> campTable;
    @FXML
    private TableColumn<Camp, String> idColumn;
    @FXML
    private TableColumn<Camp, String> dateColumn;
    @FXML
    private TableColumn<Camp, Integer> capacityColumn;
    @FXML
    private Button addButton;
    @FXML
    private Button removeButton;
    @FXML
    private TextArea textArea;

    // Database Related Fields
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    // Context Menu related
    private ContextMenu contextMenu;
    private MenuItem refreshCampData;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        textArea.setEditable(false);
        textArea.prefWidthProperty().bind(tableScrollPane.widthProperty());
        bootstrap();
    }

    public Button getAddButton() {
        return addButton;
    }

    public Button getRemoveButton() {
        return removeButton;
    }

    private void bootstrap() {
        addButton.setGraphic(new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        removeButton.setGraphic(new ImageView(getClass().getResource("images/buttons/remove.png").toExternalForm()));
        populateTableWithData();
        configureColumnsCellValueFactories();
        configureColumnsCellFactories();
        addEventsToButtons();
        addContextMenu();
    }

    private void configureColumnsCellValueFactories() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("campID"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("dateCreated"));
        capacityColumn.setCellValueFactory(new PropertyValueFactory<>("capacity"));
    }

    private void configureColumnsCellFactories() {
        idColumn.setCellFactory(tableColumn -> {
            TextFieldTableCell cell = new TextFieldTableCell(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        idColumn.setOnEditCommit(event -> {
            updateCell("camp_id", "camp_id", event.getOldValue(), event.getNewValue(), event);
        });

        dateColumn.setCellFactory((tableColumn) -> {
            DatePickerCell<Camp, String> cell = new DatePickerCell<Camp, String>();
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        dateColumn.setOnEditCommit(event -> {
            updateCell("date_created", "camp_id", event.getOldValue(), event.getNewValue(), event);
        });

        capacityColumn.setCellFactory(tableColumn -> {
            TextFieldTableCell cell = new TextFieldTableCell(new IntegerStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        capacityColumn.setOnEditCommit(event -> {
            updateCell("capacity", "camp_id", event.getOldValue().toString(), event.getNewValue().toString(), event);
        });

    }

    private void populateTableWithData() {
        ObservableList<Camp> campItems = FXCollections.observableArrayList();
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM camp_data;");

            while (resultSet.next()) {
                String campID = resultSet.getString("camp_id");
                String dateCreated = resultSet.getString("date_created");
                int capacity = resultSet.getInt("capacity");
                Camp campObject = new Camp(campID, dateCreated, capacity);
                campItems.add(campObject);
            }
            campTable.setItems(campItems);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void updateCell(String dbColumnName, String primaryKey, String oldValue, String newValue, TableColumn.CellEditEvent event) {
        try {
            statement = connection.createStatement();
            int result = statement.executeUpdate("UPDATE `livestock_farm`.`camp_data` SET `" + dbColumnName + "` ='" + newValue + "' WHERE (`" + primaryKey + "` =\"" + idColumn.getCellData(event.getTablePosition().getRow()) + "\");");
            populateTableWithData();
            campTable.getSelectionModel().select(event.getTablePosition().getRow());
        } catch (MySQLSyntaxErrorException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Please refactor the data to exclude special characters.");
            alert.initModality(Modality.APPLICATION_MODAL);
            campTable.getSelectionModel().select(event.getTablePosition().getRow());
            campTable.refresh();
            alert.showAndWait();
        } catch (SQLException ex) {
            try {
                ex.printStackTrace();
                connection.close();
                statement.close();
            } catch (SQLException ex1) {
                Logger.getLogger(CampsTabController.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }

    }

    private void addEventsToButtons() {
        addButton.setOnAction(event -> {
            displayAddMicrochipView();
        });

        removeButton.setOnAction(event -> {
            try {
                Camp campObject = campTable.getSelectionModel().getSelectedItem();
                statement.execute("DELETE FROM camp_data WHERE camp_id = '" + campObject.toString() + "';");
                populateTableWithData();
            } catch (SQLException ex) {
                ex.printStackTrace();
            } catch (NullPointerException ex) {
                displayInformationDialog();
            }
        });
    }

    private void addContextMenu() {
        contextMenu = new ContextMenu();
        refreshCampData = new MenuItem("Refresh", new ImageView(getClass().getResource("images/buttons/refresh.png").toExternalForm()));
        refreshCampData.setOnAction(eventHandler -> {
            populateTableWithData();
        });
        contextMenu.getItems().addAll(refreshCampData);
        campTable.setContextMenu(contextMenu);
    }

    private void displayInformationDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "No camp has been selected yet!", ButtonType.OK);
        alert.setTitle("Information!");
        Optional<ButtonType> result = alert.showAndWait();
        alert.setOnCloseRequest(event -> alert.close());
        if (result.get() != ButtonType.OK) {
            alert.close();
        }
    } 
    
    private void displayAddMicrochipView() {
        try {
            //Load the AddMicrochipView Stage
            FXMLLoader loader = new FXMLLoader(new URL(getClass().getResource("views/AddCampView.fxml").toExternalForm()));
            AddMicrochipViewController controller = loader.getController();
            Pane root = (Pane) loader.load();
            Stage stage = new Stage();
            stage.setTitle("Add Camp");
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.sizeToScene();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();

        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {

        }
    }

}
