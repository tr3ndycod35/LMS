/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import java.awt.Desktop;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author Cherry
 */
public class DashboardPaneController extends BorderPane implements Initializable {

    public MainApplication mainApp;
    @FXML
    private TreeView<String> dashboardTreeView;
    @FXML
    private TabPane tabPane;
//    private Tab overviewTab;
    private Tab viewAllTab = null;
    private Tab microchipsTab = null;
    private Tab campsTab = null;
    private Tab diseasesTab = null;
    private Tab deathsTab = null;
    private Tab salesTab = null;
    private Tab purchasesTab = null;
    private Tab customersTab = null;
    private Tab facebookTab = null;
    private Tab instagramTab = null;
    private Tab browserTab = null;
    
    private BrowserViewController browserViewController = null;
    private FacebookTabController facebookTabController = null;
    private InstagramTabController instagramTabController = null;

    @FXML
    private ScrollPane scollPane;
    private FXMLLoader loader;
    @FXML
    private MenuButton userActionButton;
    @FXML
    private MenuItem exitMenuItem;
    @FXML
    private MenuItem userInfoMenuItem;
    @FXML
    private MenuItem customerInfoMenuItem;
    @FXML
    private MenuItem settingsMenuItem;
    @FXML
    private MenuItem insertLivestockMenuItem;
    @FXML
    private MenuItem insertMicrochipMenuItem;
    @FXML
    private MenuItem insertCampMenuItem;
    @FXML
    private MenuItem insertDiseaseMenuItem;
    @FXML
    private MenuItem insertDeathMenuItem;
    @FXML
    private MenuItem insertSalesMenuItem;
    @FXML
    private MenuItem insertPurchaseMenuItem;
    @FXML
    private MenuItem insertCustomerMenuItem;
    @FXML
    private MenuItem emailMenuItem;
    @FXML
    private MenuItem smsMenuItem;
    @FXML
    private MenuItem instagramMenuItem;
    @FXML
    private MenuItem facebookMenuItem;

    public void setApplication(MainApplication app) {
        this.mainApp = app;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        dashboardTreeView.prefWidthProperty().bind(scollPane.widthProperty());
        dashboardTreeView.prefHeightProperty().bind(scollPane.heightProperty());

        userActionButton.setGraphic(new ImageView(getClass().getResource("images/buttons/user.png").toExternalForm()));

        populateTreeData();
        configureMenuItems();
        viewAllTab = createTab("View All", "views/ViewAllTab.fxml");
        viewAllTab.setGraphic(new ImageView((new Image(getClass().getResource("images/treeitems/list_view.png").toExternalForm()))));
        viewAllTab.setOnClosed((Event event) -> {
            tabPane.getTabs().remove(viewAllTab);
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("views/ViewAllTab.fxml"));
                Pane pane = loader.load();
                ViewAllTabController controller = loader.getController();
//                controller.connection.close();
            } catch (IOException ex) {
                System.out.println("I/O exception occured");
            }
        });

        getTabPane().getTabs().add(viewAllTab);

        microchipsTab = createTab("Microchips Information", "views/MicrochipsTab.fxml");
        microchipsTab.setGraphic(new ImageView((new Image(getClass().getResource("images/treeitems/Microchip.png").toExternalForm()))));

        campsTab = createTab("Camps Data", "views/CampsTab.fxml");
        campsTab.setGraphic(new ImageView(new Image(getClass().getResource("images/treeitems/Camp.png").toExternalForm())));
//        overviewTab.setClosable(false);

        diseasesTab = createTab("Diseases & Treatments", "views/DiseasesTreatment.fxml");
        diseasesTab.setGraphic(new ImageView(new Image(getClass().getResource("images/treeitems/Treatment.png").toExternalForm())));

        deathsTab = createTab("Deaths", "views/DeathTab.fxml");
        deathsTab.setGraphic(new ImageView(new Image(getClass().getResource("images/treeitems/Death.png").toExternalForm())));

        salesTab = createTab("Sales", "views/SalesTab.fxml");
        salesTab.setGraphic(new ImageView(new Image(getClass().getResource("images/treeitems/Sales.png").toExternalForm())));

        purchasesTab = createTab("Purchases", "views/PurchasesTab.fxml");
        purchasesTab.setGraphic(new ImageView(new Image(getClass().getResource("images/treeitems/Purchases.png").toExternalForm())));

        customersTab = createTab("Customers", "views/CustomersTab.fxml");
        customersTab.setGraphic(new ImageView(new Image(getClass().getResource("images/treeitems/Customers.png").toExternalForm())));

        facebookTabController = configureFacebookTab("Facebook", "Facebook.png");
        instagramTabController = configureInstagramTab("Instagram", "Instagram.png");
    }

    public void populateTreeData() {
        TreeItem rootItem = new TreeItem();

        TreeItem overview = makeTreeBranch("Overview", "Eye.png", rootItem);

        TreeItem manageLivestock = makeTreeBranch("Manage Livestock", "Manage.png", rootItem);
        makeTreeBranch("View All", "list_view.png", manageLivestock);
        makeTreeBranch("Microchips Information", "Microchip.png", manageLivestock);
        makeTreeBranch("Camps Data", "Camp.png", manageLivestock);
        makeTreeBranch("Diseases & Treatments", "Treatment.png", manageLivestock);
        makeTreeBranch("Deaths", "Death.png", manageLivestock);
        manageLivestock.setExpanded(true);

        TreeItem financials = makeTreeBranch("Financials", "Financials.png", rootItem);
        makeTreeBranch("Sales", "Sales.png", financials);
        makeTreeBranch("Purchases", "Purchases.png", financials);
        financials.setExpanded(true);

        TreeItem customers = makeTreeBranch("Customers", "Customers.png", rootItem);
//        TreeItem reports = makeTreeBranch("Reports", "Reports.png", rootItem);
        TreeItem marketing = makeTreeBranch("Online Marketing & Promotion", "OnlineMarketing.png", rootItem);
        TreeItem emailMarketing = makeTreeBranch("Email Marketing", "Email.png", marketing);
        TreeItem smsMarketing = makeTreeBranch("SMS", "SMS.png", marketing);
        TreeItem facebookMarketing = makeTreeBranch("Facebook", "Facebook.png", marketing);
        TreeItem instagramMarketing = makeTreeBranch("Instagram", "Instagram.png", marketing);
//        TreeItem browser = makeTreeBranch("Browser", "Browser.png", marketing);
        marketing.setExpanded(true);

//        TreeItem settings = makeTreeBranch("Settings", "Settings.png", rootItem);
        dashboardTreeView.setCellFactory(param -> new CustomizedCell());
        dashboardTreeView.setRoot(rootItem);
        dashboardTreeView.showRootProperty().set(false);
    }

    public TreeItem<String> makeTreeBranch(String title, String imageFileName, TreeItem<String> parent) {
        TreeItem<String> item;
        if (imageFileName == null) {
            item = new TreeItem<>(title);
        } else {
            ImageView graphic = new ImageView(getClass().getResource("images/treeitems/" + imageFileName).toString());
            item = new TreeItem<>(title);
            item.setGraphic(graphic);
        }
        parent.getChildren().add(item);
        return item;
    }

    public TabPane getTabPane() {
        return tabPane;
    }

    public Tab createTab(String tabName, String viewFileName) {
        Node content = null;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(viewFileName));
            content = (Node) loader.load();

        } catch (MalformedURLException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
        }

        return new Tab(tabName, content);
    }

    private void displaySendEmailDialog() {
        try {
            // Loads the SendEmail Stage
            loader = new FXMLLoader(new URL(getClass().getResource("views/SendEmailView.fxml").toExternalForm()));
            AnchorPane root = (AnchorPane) loader.load();
            SendEmailController controller = loader.getController();

            Stage stage = new Stage();
            stage.setTitle("Send Email");
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.sizeToScene();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();

        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void displaySendSMSDialog() {
        try {
            // Loads the SendSMS Stage
            loader = new FXMLLoader(new URL(getClass().getResource("views/SendSMSView.fxml").toExternalForm()));
            AnchorPane root = (AnchorPane) loader.load();
            SendSMSController controller = loader.getController();

            Stage stage = new Stage();
            stage.setTitle("Send SMS");
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.sizeToScene();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();

        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void configureMenuItems() {
        exitMenuItem.setOnAction(e -> {
            System.exit(1);
        });
    }

    private BrowserViewController configureBrowserTab(String name, String iconFile) {
        BrowserViewController controller = null;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("views/BrowserView.fxml"));
            Pane root = (Pane) loader.load();
            browserTab = new Tab(name, root);
            browserTab.setGraphic(new ImageView(getClass().getResource("images/treeitems/" + iconFile).toExternalForm()));
            controller = (BrowserViewController) loader.getController();
            //return controller;
        } catch (IOException ex) {
            Logger.getLogger(DashboardPaneController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return controller;
    }

    private FacebookTabController configureFacebookTab(String name, String iconFile) {
        FacebookTabController controller = null;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("views/FacebookTab.fxml"));
            Pane root = (Pane) loader.load();
            facebookTab = new Tab(name, root);
            facebookTab.setGraphic(new ImageView(getClass().getResource("images/treeitems/" + iconFile).toExternalForm()));
            controller = (FacebookTabController) loader.getController();
            //return controller;
        } catch (IOException ex) {
            Logger.getLogger(DashboardPaneController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return controller;
    }
    
    private InstagramTabController configureInstagramTab(String name, String iconFile) {
        InstagramTabController controller = null;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("views/InstagramTab.fxml"));
            Pane root = (Pane) loader.load();
            instagramTab = new Tab(name, root);
            instagramTab.setGraphic(new ImageView(getClass().getResource("images/treeitems/" + iconFile).toExternalForm()));
            controller = (InstagramTabController) loader.getController();
            //return controller;
        } catch (IOException ex) {
            Logger.getLogger(DashboardPaneController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return controller;
    }

    public class CustomizedCell extends TreeCell<String> {

        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);

            setText(item);
            setGraphic(getTreeItemGraphic());
            addEventHandler(MouseEvent.MOUSE_RELEASED, event -> {
                ObservableList<Tab> tabList = getTabPane().getTabs();
                TreeCell selectedCell = (TreeCell) event.getSource();
                if (item == "View All") {
                    if (tabList.contains(viewAllTab)) {
                        Platform.runLater(() -> {
                            tabPane.getSelectionModel().select(viewAllTab);
                        });

                    } else {
                        Platform.runLater(() -> {
                            tabList.add(viewAllTab);
                            tabPane.getSelectionModel().select(viewAllTab);
                        });
                    }
                } else if (item == "Microchips Information") {
                    if (tabList.contains(microchipsTab)) {
                        Platform.runLater(() -> {
                            tabPane.getSelectionModel().select(microchipsTab);
                        });

                    } else {
                        Platform.runLater(() -> {
                            tabList.add(microchipsTab);
                            tabPane.getSelectionModel().select(microchipsTab);
                        });
                    }
                } else if (item == "Camps Data") {
                    if (tabList.contains(campsTab)) {
                        Platform.runLater(() -> {
                            tabPane.getSelectionModel().select(campsTab);
                        });

                    } else {
                        Platform.runLater(() -> {
                            tabList.add(campsTab);
                            tabPane.getSelectionModel().select(campsTab);
                        });
                    }
                } else if (item == "Diseases & Treatments") {
                    if (tabList.contains(diseasesTab)) {
                        Platform.runLater(() -> {
                            tabPane.getSelectionModel().select(diseasesTab);
                        });

                    } else {
                        Platform.runLater(() -> {
                            tabList.add(diseasesTab);
                            tabPane.getSelectionModel().select(diseasesTab);
                        });
                    }
                } else if (item == "Deaths") {
                    if (tabList.contains(deathsTab)) {
                        Platform.runLater(() -> {
                            tabPane.getSelectionModel().select(deathsTab);
                        });

                    } else {
                        Platform.runLater(() -> {
                            tabList.add(deathsTab);
                            tabPane.getSelectionModel().select(deathsTab);
                        });
                    }
                } else if (item == "Sales") {
                    if (tabList.contains(salesTab)) {
                        Platform.runLater(() -> {
                            tabPane.getSelectionModel().select(salesTab);
                        });

                    } else {
                        Platform.runLater(() -> {
                            tabList.add(salesTab);
                            tabPane.getSelectionModel().select(salesTab);
                        });
                    }
                } else if (item == "Purchases") {
                    if (tabList.contains(purchasesTab)) {
                        Platform.runLater(() -> {
                            tabPane.getSelectionModel().select(purchasesTab);
                        });

                    } else {
                        Platform.runLater(() -> {
                            tabList.add(purchasesTab);
                            tabPane.getSelectionModel().select(purchasesTab);
                        });
                    }
                } else if (item == "Customers") {
                    if (tabList.contains(customersTab)) {
                        Platform.runLater(() -> {
                            tabPane.getSelectionModel().select(customersTab);
                        });

                    } else {
                        Platform.runLater(() -> {
                            tabList.add(customersTab);
                            tabPane.getSelectionModel().select(customersTab);
                        });
                    }
                } else if (item == "Email Marketing") {
                    displaySendEmailDialog();
                } else if (item == "SMS") {
                    // displaySendSMSDialog();
                    displaySendSMSDialog();
                } else if (item == "Facebook") {
                    // Try connecting to the Internet
                    if (connectedToInternet()) {
                        // Open Facebook in default browser;
                        if (tabList.contains(facebookTab)) {
                            Platform.runLater(() -> {
                                tabPane.getSelectionModel().select(facebookTab);
                                facebookTabController.getBrowserWebView().getEngine().load("https://www.facebook.com/");
                            });

                        } else {
                            Platform.runLater(() -> {                      
                                tabList.add(facebookTab);
                                tabPane.getSelectionModel().select(facebookTab);
                                facebookTabController.getBrowserWebView().getEngine().load("https://www.facebook.com/");
                            });
                        }
                    }

                } else if (item == "Instagram") {
                    if (connectedToInternet()) {
                        // Open Instagram in application's tab
                        if (tabList.contains(instagramTab)) {
                            Platform.runLater(() -> {
                                tabPane.getSelectionModel().select(instagramTab);
                                instagramTabController.getBrowserWebView().getEngine().load("https://www.instagram.com/");
                            });

                        } else {
                            Platform.runLater(() -> {
                                tabList.add(instagramTab);
                                tabPane.getSelectionModel().select(instagramTab);
                                instagramTabController.getBrowserWebView().getEngine().load("https://www.instagram.com/");
                            });
                        }
                    }
                } 
            });
        }
       
        private Node getTreeItemGraphic() {
            TreeItem<String> treeItem = getTreeItem();
            if (treeItem == null) {
                return null;
            }
            return treeItem.getGraphic();
        }

        private boolean connectedToInternet() {
            boolean connected = false;
            try {
                Socket socket = new Socket();
                socket.connect(new InetSocketAddress(InetAddress.getByName("google.com"), 80));
                connected = true;
            } catch (IOException ex) {
                displayInformationDialog("Application is not connected to the Internet."
                        + " Please make sure Internet is live then try again.");
            }
            return connected;
        }

        private void displayInformationDialog(String message) {
            Platform.runLater(new Runnable() {
                Alert alert;

                @Override
                public void run() {
                    try {
                        alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
                        alert.setTitle("Information!");
                        Optional<ButtonType> result = alert.showAndWait();
                        alert.setOnCloseRequest(event -> alert.close());
                    } catch (NoSuchElementException ex) {
                    }
                }
            });
        }
    }

}
