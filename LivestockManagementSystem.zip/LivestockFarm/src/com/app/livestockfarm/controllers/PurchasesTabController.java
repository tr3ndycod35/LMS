/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.beans.Purchases;
import com.app.livestockfarm.beans.Sales;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.DefaultStringConverter;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class PurchasesTabController implements Initializable {

    @FXML
    private ScrollPane tableScrollPane;
    @FXML
    private TableView<Purchases> purchasesTable;
    @FXML
    private TableColumn<Purchases, String> purchasedIDColumn;
    @FXML
    private TableColumn<Purchases, String> typeColumn;
    @FXML
    private TableColumn<Purchases, String> productColumn;
    @FXML
    private TableColumn<Purchases, String> datePurchasedColumn;
    @FXML
    private TableColumn<Purchases, String> customerColumn;
    @FXML
    private TableColumn<Purchases, Double> priceColumn;

    // Database related fields
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    // Context Menu related fields
    private ContextMenu contextMenu;
    private MenuItem registerPurchaseContextMenu;
    private MenuItem removePurchaseContextMenu;
    private MenuItem refreshPurchaseContextMenu;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        purchasesTable.prefHeightProperty().bind(tableScrollPane.heightProperty());
        purchasesTable.prefWidthProperty().bind(tableScrollPane.widthProperty());
        setTableProperties();
        populateTableWithData();
    }

    private void populateTableWithData() {

        ObservableList<Purchases> items = FXCollections.observableArrayList();
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM purchase_data;");

            while (resultSet.next()) {
                String purchasedID = resultSet.getString("purchase_id");
                String type = resultSet.getString("type");
                String productDescription = resultSet.getString("product");
                String datePurchased = resultSet.getString("date_purchased");
                String vendor = resultSet.getString("vendor");
                double price = resultSet.getDouble("price");
                Purchases purchasedObject = new Purchases(purchasedID, type, productDescription, datePurchased, vendor, price);
                items.add(purchasedObject);
            }
            purchasesTable.setItems(items);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void setTableProperties() {
        purchasesTable.setEditable(true);
        configureTableColumns();
        addContextMenu();
    }

    private void configureTableColumns() {
        setCellValueFactories();
        setCellFactories();
        attachEventsToTableColumns();
    }

    private void setCellValueFactories() {
        purchasedIDColumn.setCellValueFactory(new PropertyValueFactory<>("purchaseID"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        productColumn.setCellValueFactory(new PropertyValueFactory<>("productDescription"));
        datePurchasedColumn.setCellValueFactory(new PropertyValueFactory<>("datePurchased"));
        customerColumn.setCellValueFactory(new PropertyValueFactory<>("vendor"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

    }

    private void setCellFactories() {
        purchasedIDColumn.setCellFactory(value -> {
            TextFieldTableCell<Purchases, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        typeColumn.setCellFactory(value -> {
            ComboBoxTableCell<Purchases, String> cell = new ComboBoxTableCell<>("Feed", "Equipment", "Other...");
            cell.setConverter(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        productColumn.setCellFactory(value -> {
            TextFieldTableCell<Purchases, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        datePurchasedColumn.setCellFactory(value -> {
            DatePickerCell<Purchases, String> cell = new DatePickerCell<>();
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        
        customerColumn.setCellFactory(value -> {
            TextFieldTableCell<Purchases, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        priceColumn.setCellFactory(value -> {
            TextFieldTableCell<Purchases, Double> cell = new TextFieldTableCell<>(new DoubleStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

    }

    private void attachEventsToTableColumns() {
        purchasedIDColumn.setOnEditCommit(eventHandler -> {
            updateCell("purchase_id", "purchase_id", eventHandler.getOldValue().toString(), eventHandler.getNewValue().toString(), eventHandler);
        });
        typeColumn.setOnEditCommit(eventHandler -> {
            updateCell("type", "purchase_id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });

        productColumn.setOnEditCommit(eventHandler -> {
            updateCell("product_", "purchase_id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        
        datePurchasedColumn.setOnEditCommit(eventHandler -> {
            updateCell("date_purchased", "purchase_id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        
        customerColumn.setOnEditCommit(eventHandler -> {
            updateCell("vendor", "purchase_id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        priceColumn.setOnEditCommit(eventHandler -> {
            updateCell("price", "purchase_id", eventHandler.getOldValue().toString(), eventHandler.getNewValue().toString(), eventHandler);
        });

    }

    private void updateCell(String dbColumnName, String primaryKey, String oldValue, String newValue, TableColumn.CellEditEvent event) {
        try {
            statement = connection.createStatement();
            int result = statement.executeUpdate("UPDATE `livestock_farm`.`purchase_data` SET `" + dbColumnName + "` ='" + newValue + "' WHERE (`" + primaryKey + "` =\"" + purchasedIDColumn.getCellData(event.getTablePosition().getRow()) + "\");");
            populateTableWithData();
        } catch (MySQLSyntaxErrorException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Please refactor the data to exclude special characters.");
            alert.initModality(Modality.APPLICATION_MODAL);
            purchasesTable.getSelectionModel().select(event.getTablePosition().getRow());
            purchasesTable.refresh();
            alert.showAndWait();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void addContextMenu() {
        contextMenu = new ContextMenu();

        registerPurchaseContextMenu = new MenuItem("Register Purchase", new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        registerPurchaseContextMenu.setOnAction(event -> {
            displayRegisterPurchaseView();
        });

        removePurchaseContextMenu = new MenuItem("Delete Purchase Record", new ImageView(getClass().getResource("images/buttons/remove.png").toExternalForm()));
        removePurchaseContextMenu.setOnAction(eventHandler -> {

            Purchases purchaseObject = purchasesTable.getSelectionModel().getSelectedItem();
            try {
                statement.execute("DELETE FROM purchase_data WHERE purchase_id = '" + purchaseObject.toString() + "';");
                populateTableWithData();
            } catch (SQLException ex) {
                ex.printStackTrace();
                displayInformationDialog();
            } catch (NullPointerException ex) {
                displayInformationDialog();
            }
        });

        refreshPurchaseContextMenu = new MenuItem("Refresh Purchases", new ImageView(getClass().getResource("images/buttons/refresh.png").toExternalForm()));
        refreshPurchaseContextMenu.setOnAction(eventHandler -> {
            populateTableWithData();
        });
        contextMenu.getItems().addAll(refreshPurchaseContextMenu, registerPurchaseContextMenu, removePurchaseContextMenu);
        purchasesTable.setContextMenu(contextMenu);
    }

    private void displayRegisterPurchaseView() {
        try {
            //Load the AddMicrochipView Stage
            FXMLLoader loader = new FXMLLoader(new URL(getClass().getResource("views/RegisterPurchase.fxml").toExternalForm()));
            Pane root = (Pane) loader.load();
            Stage stage = new Stage();
            stage.setTitle("Register Purchase");
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.sizeToScene();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();

        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void displayInformationDialog() {
        try {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No purchase record has been selected yet!", ButtonType.OK);
            alert.setTitle("Information!");
            Optional<ButtonType> result = alert.showAndWait();
            alert.setOnCloseRequest(event -> alert.close());
            if (result.get() != ButtonType.OK) {
                alert.close();
            }
        } catch (NoSuchElementException ex) {
        }
    }

}
