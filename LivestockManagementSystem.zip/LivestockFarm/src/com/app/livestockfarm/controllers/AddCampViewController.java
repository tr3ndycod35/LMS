/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class AddCampViewController implements Initializable {

    @FXML
    private TextField campIDTextField;
    @FXML
    private DatePicker dateCreatedPicker;
    @FXML
    private TextField capacityTextField;
    @FXML
    private Label errorLabel;
    @FXML
    private Button addCampButton;
    private Connection connection;
    private PreparedStatement statement;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        bootstrap();
    }

    private void bootstrap() {
        addCampButton.setGraphic(new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        addCampButton.setOnAction(event -> {
            persistData();
            resetFields();
        });
        dateCreatedPicker.setValue(LocalDate.now());
    }

    private void persistData() {
        if (validateInputFields()) {
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.prepareStatement("INSERT INTO `livestock_farm`.`camp_data` "
                        + "                              VALUES (?, ?, ?);");
                String campID = campIDTextField.getText();
                String dateCreated = dateCreatedPicker.getValue().toString();
                int capacity = Integer.valueOf(capacityTextField.getText());
                statement.setString(1, campID);
                statement.setString(2, dateCreated);
                statement.setInt(3, capacity);
                boolean result = statement.execute();
                if(result == false) {
                    displayOKDialog("Camp " + campID + " has been added successfully!");
                }
            } catch (SQLException ex) {
                animateLabel(errorLabel, "Fill all empty fields!");
            } catch (NumberFormatException ex) {
                animateLabel(errorLabel, "Capacity can only be a number");
            }
        }
    }

    private boolean validateInputFields() {
        boolean everythingSet;
        if (campIDTextField.getText() == null || campIDTextField.getText() == "" || campIDTextField.getText().isEmpty()
                || capacityTextField.getText() == null || capacityTextField.getText() == "" || capacityTextField.getText().isEmpty()) {
            animateLabel(errorLabel, "Fill empty fields!");
            everythingSet = false;
            return everythingSet;
        } else {
            everythingSet = true;
        }
        return everythingSet;
    }

    private void animateLabel(Label errorlabel, String message) {
        errorLabel.setText(message);
        errorLabel.setOpacity(1.0);
        FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
        transition1.setFromValue(1.0);
        transition1.setToValue(0.0);
        transition1.play();
    }

    private void resetFields() {
        campIDTextField.setText(null);
        capacityTextField.setText(null);
        dateCreatedPicker.setValue(LocalDate.now());
    }

    private void displayOKDialog(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done!");
            alert.setContentText(message);
            alert.initModality(Modality.APPLICATION_MODAL);
            alert.showAndWait();
    }
}
