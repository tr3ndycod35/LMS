/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class RegisterPurchaseController implements Initializable {

    @FXML
    private Label errorLabel;
    @FXML
    private TextField purchaseIDTextField;
    @FXML
    private ComboBox<String> typeComboBox;
    @FXML
    private TextField productDescTextField;
    @FXML
    private DatePicker datePurchasedDatePicker;
    @FXML
    private TextField customerTextField;
    @FXML
    private TextField priceTextField;
    @FXML
    private Button registerPurchaseButton;

    private Connection connection;
    private PreparedStatement statement;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        bootstrap();
    }

    private void bootstrap() {
        registerPurchaseButton.setGraphic(new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        registerPurchaseButton.setOnAction(event -> {

            if (persistData()) {
                resetFields();
            }
        });
        datePurchasedDatePicker.setValue(LocalDate.now());
        typeComboBox.setItems(FXCollections.observableArrayList("Feed", "Equipment", "Other"));
    }

    private boolean persistData() {
        boolean done = false;
        if (validateInputFields()) {
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.prepareStatement("INSERT INTO `livestock_farm`.`purchase_data` "
                        + "                              VALUES (?, ?, ?, ?, ?, ?);");
                String purchaseID = purchaseIDTextField.getText();
                String type = typeComboBox.getSelectionModel().getSelectedItem().toString();
                String productDescription = productDescTextField.getText();
                String datePurchased = datePurchasedDatePicker.getValue().toString();
                String vendor = customerTextField.getText();
                double price = Double.valueOf(priceTextField.getText());

                statement.setString(1, purchaseID);
                statement.setString(2, type);
                statement.setString(3, productDescription);
                statement.setString(4, datePurchased);
                statement.setString(5, vendor);
                statement.setDouble(6, price);

                boolean result = statement.execute();
                if (result == false) {
                    displayOKDialog("Purchase " + purchaseID + " has been registered successfully!");
                    done = true;
                } else {
                    done = false;
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                //animateLabel(errorLabel, ex.getMessage());
            } catch (NumberFormatException ex) {
                animateLabel(errorLabel, "Both transaction id and price can only be number");
            }
        }
        return done;
    }

    private boolean validateInputFields() {
        boolean everythingSet;
        if (purchaseIDTextField.getText() == null || purchaseIDTextField.getText() == "" || purchaseIDTextField.getText().isEmpty()
                || priceTextField.getText() == null || priceTextField.getText() == "" || priceTextField.getText().isEmpty()
                || customerTextField.getText() == null || customerTextField.getText() == "" || customerTextField.getText().isEmpty()
                || productDescTextField.getText() == null || productDescTextField.getText() == "" || productDescTextField.getText().isEmpty()) {
            animateLabel(errorLabel, "Fill empty fields!");
            everythingSet = false;
            return everythingSet;
        } else {
            everythingSet = true;
        }
        return everythingSet;
    }

    private void animateLabel(Label errorlabel, String message) {
        errorLabel.setText(message);
        errorLabel.setOpacity(1.0);
        FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
        transition1.setFromValue(1.0);
        transition1.setToValue(0.0);
        transition1.play();
    }

    private void resetFields() {
        purchaseIDTextField.setText(null);
        typeComboBox.getSelectionModel().clearSelection();
        productDescTextField.setText(null);
        datePurchasedDatePicker.setValue(LocalDate.now());
        customerTextField.setText(null);
        priceTextField.setText(null);

    }

    private void displayOKDialog(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done!");
        alert.setContentText(message);
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.showAndWait();
    }

}
