/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.web.WebView;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class InstagramTabController implements Initializable {

    @FXML
    private ScrollPane scrollPane;
    @FXML
    private WebView browserWebView;
    @FXML
    private ProgressBar progressBar;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        progressBar.prefWidthProperty().bind(scrollPane.widthProperty());
        progressBar.progressProperty().bind(browserWebView.getEngine().getLoadWorker().progressProperty());
    }

    public ProgressBar getProgressBar() {
        return progressBar;
    }

    public WebView getBrowserWebView() {
        return browserWebView;
    }

}
