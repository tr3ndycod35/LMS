/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.Validator;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class LivestockDetailsController implements Initializable {

    @FXML
    private Button okButton;
    @FXML
    private Button prevItemButton;
    @FXML
    private Button nextItemButton;
    @FXML
    private Tab basicTab;
    @FXML
    private TextField animalIDTextField;
    @FXML
    private ComboBox<String> animalTypeComboBox;
    @FXML
    private ComboBox<String> animalSourceComboBox;
    @FXML
    private DatePicker dobDatePicker;
    @FXML
    private ComboBox<String> sexComboBox;
    @FXML
    private TextField weightTextField;
    @FXML
    private TextField breedTextField;
    @FXML
    private TextField colorTextField;
    @FXML
    private TextField sireIDTextField;
    @FXML
    private TextField damIDTextField;
    @FXML
    private TextField microchipTextField;
    @FXML
    private TextField bookValueTextField;
    @FXML
    private TextField marketValueTextField;
    @FXML
    private TextField campIDTextField;
    @FXML
    private ImageView imageDisplayLabel;
    @FXML
    private Tab purchaseDataTab;
    @FXML
    private Tab vaccinationsTab;
    @FXML
    private Tab diseasesTab;
    @FXML
    private Tab veterinarianTab;
    @FXML
    private Button cancelButton;
    @FXML
    private Label errorLabel;
    @FXML
    private DatePicker datePurchasePicker;
    @FXML
    private TextField sellerTextField;
    @FXML
    private TextField priceTextField;
    @FXML
    private DatePicker arrivalDatePicker;
    @FXML
    private TableView<?> vaccinationTableView;
    @FXML
    private TableView<?> diseasesTable;
    @FXML
    private TableView<?> veterinarianTableView;

    private Connection connection;
    private PreparedStatement statement;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        prevItemButton.setGraphic(new ImageView(getClass().getResource("images/buttons/previous.png").toExternalForm()));
        nextItemButton.setGraphic(new ImageView(getClass().getResource("images/buttons/next.png").toExternalForm()));
        animalIDTextField.setEditable(false);

        initializeComboboxes();

        okButton.setOnAction((actionEvent) -> {
            // Save basic information
            String id = animalIDTextField.getText();
            String type = animalTypeComboBox.getSelectionModel().getSelectedItem();
            String source = animalSourceComboBox.getSelectionModel().getSelectedItem();
            LocalDate dob = dobDatePicker.getValue();
            String sex = sexComboBox.getSelectionModel().getSelectedItem();
            double weight = Validator.validateNumber("Weight value ", weightTextField.getText(), errorLabel);
            String breed = breedTextField.getText();
            String color = colorTextField.getText();
            String sireID = sireIDTextField.getText();
            String damID = damIDTextField.getText();
            String microchip = microchipTextField.getText();
            double bookValue = Validator.validateNumber("Book value", bookValueTextField.getText(), errorLabel);
            double marketValue = Validator.validateNumber("Market value", marketValueTextField.getText(), errorLabel);

            try {// sire_id, dam_id, microchip, book_value, market_value
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.prepareStatement("UPDATE `livestock_farm`.`livestock_table`"
                        + "                              SET `type`         = ?,"
                        + "                                  `source`       = ?,"
                        + "                                  `birth_date`   = ?,"
                        + "                                  `sex`          = ?,"
                        + "                                  `weight`       = ?,"
                        + "                                  `breed`        = ?,"
                        + "                                  `color`        = ?,"
                        + "                                  `sire_id`      = ?,"
                        + "                                  `dam_id`       = ?,"
                        + "                                  `microchip_id` = ?,"
                        + "                                  `book_value`   = ?,"
                        + "                                  `market_value` = ?"
                        + "                              WHERE (`animal_id` = ?);");
                statement.setString(1, type);
                statement.setString(2, source);
                statement.setString(3, dob.toString());
                statement.setString(4, sex);
                statement.setDouble(5, weight);
                statement.setString(6, breed);
                statement.setString(7, color);
                statement.setString(8, sireID);
                statement.setString(9, damID);
                statement.setString(10, microchip);
                statement.setDouble(11, bookValue);
                statement.setDouble(12, marketValue);
                statement.setString(13, id);

                boolean result = statement.execute();

                // Update the purchases table
                LocalDate datePurchased = datePurchasePicker.getValue();
                String seller = sellerTextField.getText();
                double price = Validator.validateNumber("Price", priceTextField.getText(), errorLabel);
                LocalDate arrivalDate = arrivalDatePicker.getValue();
                
                statement = connection.prepareStatement(sex);
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

        });

    }

    public ComboBox<String> getAnimalSourceComboBox() {
        return animalSourceComboBox;
    }

    public void setAnimalSourceComboBox(ComboBox<String> animalSourceComboBox) {
        this.animalSourceComboBox = animalSourceComboBox;
    }

    public void initializeComboboxes() {
        animalTypeComboBox.getItems().addAll("Cattle", "Goat", "Pig", "Rabbit");
        sexComboBox.getItems().addAll("Male", "Female");
        animalSourceComboBox.getItems().addAll("Birth", "Purchased");

    }

    public Button getPrevItemButton() {
        return prevItemButton;
    }

    public Button getNextItemButton() {
        return nextItemButton;
    }

    public Button getCancelButton() {
        return cancelButton;
    }

    public TextField getAnimalIDTextField() {
        return animalIDTextField;
    }

    public ComboBox<String> getAnimalTypeComboBox() {
        return animalTypeComboBox;
    }

    public DatePicker getDobDatePicker() {
        return dobDatePicker;
    }

    public ComboBox<String> getSexComboBox() {
        return sexComboBox;
    }

    public TextField getWeightTextField() {
        return weightTextField;
    }

    public TextField getBreedTextField() {
        return breedTextField;
    }

    public TextField getColorTextField() {
        return colorTextField;
    }

    public TextField getSireIDTextField() {
        return sireIDTextField;
    }

    public TextField getDamIDTextField() {
        return damIDTextField;
    }

    public TextField getMicrochipTextField() {
        return microchipTextField;
    }

    public TextField getBookValueTextField() {
        return bookValueTextField;
    }

    public TextField getMarketValueTextField() {
        return marketValueTextField;
    }

    public TextField getCampIDTextField() {
        return campIDTextField;
    }

    public ImageView getImageDisplayLabel() {
        return imageDisplayLabel;
    }

    public Button getOkButton() {
        return okButton;
    }

    public DatePicker getDatePurchasePicker() {
        return datePurchasePicker;
    }

    public TextField getSellerTextField() {
        return sellerTextField;
    }

    public TextField getPriceTextField() {
        return priceTextField;
    }

    public DatePicker getArrivalDatePicker() {
        return arrivalDatePicker;
    }

    public TableView<?> getVaccinationTableView() {
        return vaccinationTableView;
    }

    public TableView<?> getDiseasesTable() {
        return diseasesTable;
    }

    public TableView<?> getVeterinarianTableView() {
        return veterinarianTableView;
    }

}
