/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class AddMicrochipViewController implements Initializable {

    // UX/UI fields
    @FXML
    private TextField microchipIDTextField;
    @FXML
    private TextField manufacturerTextField;
    @FXML
    private DatePicker dateimplantedPicker;
    @FXML
    private Label errorLabel;
    @FXML
    private Button addButton;

    // Database related fields
    private Connection connection;
    private PreparedStatement statement;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        bootstrap();
    }

    public Button getAddButton() {
        return addButton;
    }

    private void bootstrap() {
        addButton.setGraphic(new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        addButton.setOnAction(event -> {
            persistData();
            resetFields();
        });
        dateimplantedPicker.setValue(LocalDate.now());
    }

    private void persistData() {
        if (validateInputFields()) {
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.prepareStatement("INSERT INTO `livestock_farm`.`microchip_data` "
                        + "                              VALUES (?, ?, ?);");
                String microchipID = microchipIDTextField.getText();
                String manufacturer = manufacturerTextField.getText();
                String dateImplanted = dateimplantedPicker.getValue().toString();
                statement.setString(1, microchipID);
                statement.setString(3, manufacturer);
                statement.setString(2, dateImplanted);
                boolean result = statement.execute();
                if (result == false) {
                    displayOKDialog("Microchip " + microchipID + " has been added successfully!");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    
    }

    private boolean validateInputFields() {
        boolean everythingSet;
        if (microchipIDTextField.getText() == null || microchipIDTextField.getText() == "" || microchipIDTextField.getText().isEmpty()
                || manufacturerTextField.getText() == null || manufacturerTextField.getText() == "" || manufacturerTextField.getText().isEmpty()) {
            animateLabel(errorLabel);
            everythingSet = false;
            return everythingSet;
        } else {
            everythingSet = true;
        }
        return everythingSet;
    }

    private void animateLabel(Label errorlabel) {
        errorLabel.setText("Fill empty fields!");
        errorLabel.setOpacity(1.0);
        FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
        transition1.setFromValue(1.0);
        transition1.setToValue(0.0);
        transition1.play();
    }

    private void resetFields() {
        microchipIDTextField.setText(null);
        manufacturerTextField.setText(null);
        dateimplantedPicker.setValue(LocalDate.now());
    }

    private void displayOKDialog(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done!");
        alert.setContentText(message);
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.showAndWait();
    }
    
}
