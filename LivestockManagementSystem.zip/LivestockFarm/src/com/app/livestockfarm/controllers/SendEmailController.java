/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.sun.mail.util.MailConnectException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.web.WebView;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class SendEmailController implements Initializable {

    @FXML
    private Tab sendMessageTab;
    @FXML
    private Button sendEmailButton;
    @FXML
    private TextField fromTextField;
    @FXML
    private TextField toTextField;
    @FXML
    private TextField subjectTextField;
    @FXML
    private TextArea messageTextArea;
    @FXML
    private Tab messagePreviewTab;
    @FXML
    private WebView webView;
    @FXML
    private Tab consoleTab;
    @FXML
    private TextArea consoleTextArea;
    @FXML
    private Tab settingsTab;
    @FXML
    private TextField emailTextField;
    @FXML
    private TextField serverTextField;
    @FXML
    private TextField userTextField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private CheckBox secureAuthCheckBox;
    @FXML
    private Button testConnectionButton;
    @FXML
    private Label informationLabel;
    @FXML
    private ComboBox<String> messageTypeComboBox;
    @FXML
    private Button saveConfigurationButton;
    @FXML
    private ComboBox<String> protocolComboBox;
    private Connection connection;
    private PreparedStatement statement;
    @FXML
    private TextField displayNameTextField;
    private String protocol;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        bootstrap();
        loadTypeComboBox();
        loadProtocolComboBox();
        configureSecureAuthCheckBox();
        loadEmailConfigurations();
        configureSendButton();

        messageTextArea.setOnMouseExited(handler -> {
            webView.getEngine().loadContent(messageTextArea.getText());
        });
    }

    private void bootstrap() {
        sendEmailButton.setGraphic(new ImageView(getClass().getResource("images/buttons/send_message.png").toExternalForm()));
        configureSaveConfigurationsButton();
        messageTextArea.setWrapText(true);
//        webView.getEngine().loadContent(messageTextArea.getText());
    }

    private void loadTypeComboBox() {
        messageTypeComboBox.getItems().addAll("Plain Text", "HTML");
        messageTypeComboBox.getSelectionModel().select("Plain Text");
    }

    private void loadProtocolComboBox() {
        protocolComboBox.getItems().addAll("SMTP", "SMTPS");
        protocolComboBox.getSelectionModel().select(0);
    }

    private void configureSaveConfigurationsButton() {
        saveConfigurationButton.setGraphic(new ImageView(getClass().getResource("images/buttons/save.png").toExternalForm()));
        saveConfigurationButton.setOnAction(handler -> {
            String fromEmail = emailTextField.getText();
            
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.prepareStatement("UPDATE `livestock_farm`.`email_settings`"
                        + "                                                  SET `from_email`   = ?,"
                        + "                                                      `display_name` = ?,"
                        + "                                                      `server`       = ?,"
                        + "                                                      `protocol`     = ?,"
                        + "                                                      `username`     = ?,"
                        + "                                                      `password`     = ?"
                        + "                                                  WHERE (`from_email` = ?);");
                statement.setString(1, emailTextField.getText());
                statement.setString(2, displayNameTextField.getText());
                statement.setString(3, serverTextField.getText());
                statement.setString(4, protocolComboBox.getSelectionModel().getSelectedItem());
                statement.setString(5, userTextField.getText());
                statement.setString(6, passwordField.getText());
                statement.setString(7, fromEmail);
                int updateDone = statement.executeUpdate();
                if (updateDone == 0) {
                    displayInformationDialog("Configuration Saved");
                }
                connection.close();
            } catch (SQLException ex) {
                displayInformationDialog(ex.getMessage());
            }

        });
    }

    private void loadEmailConfigurations() {
        try {
            statement = connection.prepareStatement("SELECT * FROM email_settings");
            ResultSet resultSet = statement.executeQuery();
            resultSet.next();
            emailTextField.setText(resultSet.getString("from_email"));
            serverTextField.setText(resultSet.getString("server"));
            String displayName = resultSet.getString("display_name");
            displayNameTextField.setText(displayName);
            fromTextField.setText(displayName + " <" + emailTextField.getText() + ">");
            protocolComboBox.getSelectionModel().select(resultSet.getString("protocol"));
            userTextField.setText(resultSet.getString("username"));
            passwordField.setText(resultSet.getString("password"));
            if (protocolComboBox.getSelectionModel().getSelectedItem() == "SMTPS") {
                secureAuthCheckBox.setSelected(true);
            } else {
                secureAuthCheckBox.setSelected(false);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void configureSecureAuthCheckBox() {
        secureAuthCheckBox.setOnAction(e -> {
            if (secureAuthCheckBox.isSelected()) {
                protocolComboBox.getSelectionModel().select(1);
            } else {
                protocolComboBox.getSelectionModel().select(0);
            }
        }
        );
    }

    private void configureSendButton() {
        sendEmailButton.setOnAction(handler -> {
            try {
                Properties mailProperties = new Properties();
                final Session session = Session.getInstance(mailProperties);
                final Message message = new MimeMessage(session);

                InternetAddress fromAddress = new InternetAddress(emailTextField.getText());
                InternetAddress toAddress = new InternetAddress(toTextField.getText());

                String content = messageTextArea.getText();
                if (messageTypeComboBox.getSelectionModel().getSelectedItem() == "Plain Text") {
                    message.setContent(content, "text/plain");
                } else if (messageTypeComboBox.getSelectionModel().getSelectedItem() == "HTML") {
                    message.setContent(content, "text/html");
                }

                message.setFrom(fromAddress);
                message.setRecipient(Message.RecipientType.TO, toAddress);
                message.setSubject(subjectTextField.getText());

                final String server = serverTextField.getText();
                final String username = userTextField.getText();
                final String password = passwordField.getText();

                if (protocolComboBox.getSelectionModel().getSelectedItem() == "SMTPS") {
                    protocol = "smtps";
                } else {
                    protocol = "smtp";
                }

                // Sending a message can take a non-trivial amount of time so
                // spawn a thread to handle it.
                Runnable runnable = new Runnable() {

                    @Override
                    public void run() {
                        Transport transport = null;
                        try {
                            transport = session.getTransport(protocol);
                            transport.connect(server, username, password);
                            transport.sendMessage(message, message.getAllRecipients());
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    displayInformationDialog("Email has been sent successfully");
                                }
                            });
                        } catch (NoSuchProviderException ex) {
                            displayInformationDialog("This current provider is not found,");
                            consoleTextArea.appendText(ex.getMessage() + "\n");
                        } catch (MailConnectException ex) {
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    displayInformationDialog("Connection to SMTP server failed, please check Internet connection.");
                                }
                            });
                            
                        } catch (MessagingException ex) {
                            ex.printStackTrace();
                            displayInformationDialog(ex.getMessage());
                            consoleTextArea.appendText(ex.getMessage() + "\n");
                        } finally {
                            if (transport != null) {
                                try {
                                    transport.close();
                                } catch (MessagingException ex) {

                                }
                            }
                        }
                    }
                };

                Thread thread = new Thread(runnable);
                thread.start();
            } catch (AddressException ex) {
                displayInformationDialog("The address is invalid.");
                consoleTextArea.appendText(ex.getMessage() + "\n");
            } catch (MessagingException ex) {
                displayInformationDialog(ex.getMessage());
                consoleTextArea.appendText(ex.getMessage() + "\n");
            }
        });
    }

    private void displayInformationDialog(String message) {
        try {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
            alert.setTitle("Information!");
            Optional<ButtonType> result = alert.showAndWait();
            alert.setOnCloseRequest(event -> alert.close());
            if (result.get() != ButtonType.OK) {
                alert.close();
            }
        } catch (NoSuchElementException ex) {
        }
    }
}
