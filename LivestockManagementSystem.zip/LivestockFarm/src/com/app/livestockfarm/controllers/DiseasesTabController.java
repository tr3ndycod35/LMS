/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.beans.DiseasesTreatments;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.DefaultStringConverter;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class DiseasesTabController implements Initializable {

    @FXML
    private ScrollPane tableScrollPane;
    @FXML
    private TableColumn<DiseasesTreatments, String> idColumn;
    @FXML
    private TableColumn<DiseasesTreatments, String> livestockColumn;
    @FXML
    private TableColumn<DiseasesTreatments, String> diseaseColumn;
    @FXML
    private TableColumn<DiseasesTreatments, String> dateColumn;
    @FXML
    private TableColumn<DiseasesTreatments, String> veterinarianColumn;
    @FXML
    private TableColumn<DiseasesTreatments, String> medicineColumn;
    @FXML
    private TableColumn<DiseasesTreatments, String> remarksColumn;
    @FXML
    private TableView<DiseasesTreatments> diseasesTable;

    // Database related fields
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    // Context Menu related fields
    private ContextMenu contextMenu;
    private MenuItem registerDiseaseContextMenu;
    private MenuItem removeDiseaseContextMenu;
    private MenuItem refreshDiseaseContextMenu;
    
    private FXMLLoader fxmlLoader;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        diseasesTable.prefHeightProperty().bind(tableScrollPane.heightProperty());
        diseasesTable.prefWidthProperty().bind(tableScrollPane.widthProperty());
        setTableProperties();
        populateTableWithData();
    }

    private void populateTableWithData() {

        ObservableList<DiseasesTreatments> items = FXCollections.observableArrayList();
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM diseases_treatment_data;");

            while (resultSet.next()) {
                String diseaseID = resultSet.getString("id");
                String animalID = resultSet.getString("livestock_id");
                String illness = resultSet.getString("illness");
                String dateIll = resultSet.getString("date_ill");
                String veterinarianName = resultSet.getString("veterinarian_name");
                String medicine = resultSet.getString("medicine");
                String remark = resultSet.getString("remarks");
                DiseasesTreatments microchipObject = new DiseasesTreatments(diseaseID, animalID, illness, dateIll, veterinarianName, medicine, remark);
                items.add(microchipObject);
            }
            diseasesTable.setItems(items);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void setTableProperties() {
        diseasesTable.setEditable(true);
        configureTableColumns();
        addContextMenu();
    }

    private void configureTableColumns() {
        setCellValueFactories();
        setCellFactories();
        attachEventsToTableColumns();
    }

    private void setCellValueFactories() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        livestockColumn.setCellValueFactory(new PropertyValueFactory<>("livestock"));
        diseaseColumn.setCellValueFactory(new PropertyValueFactory<>("Illness"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("dateIll"));
        veterinarianColumn.setCellValueFactory(new PropertyValueFactory<>("veterinarianName"));
        medicineColumn.setCellValueFactory(new PropertyValueFactory<>("medicine"));
        remarksColumn.setCellValueFactory(new PropertyValueFactory<>("remarks"));

    }

    private void setCellFactories() {
        idColumn.setCellFactory(value -> {
            TextFieldTableCell<DiseasesTreatments, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        livestockColumn.setCellFactory(value -> {
            ObservableList<String> livestockList = FXCollections.observableArrayList();
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.createStatement();
                resultSet = statement.executeQuery("SELECT animal_id FROM livestock_table;");
                while (resultSet.next()) {
                    livestockList.add(resultSet.getString("animal_id"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            ComboBoxTableCell<DiseasesTreatments, String> cell = new ComboBoxTableCell<>(livestockList);
            cell.setConverter(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        diseaseColumn.setCellFactory(value -> {
            TextFieldTableCell<DiseasesTreatments, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        dateColumn.setCellFactory(value -> {
            DatePickerCell<DiseasesTreatments, String> cell = new DatePickerCell<>();
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        veterinarianColumn.setCellFactory(value -> {
            TextFieldTableCell<DiseasesTreatments, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        medicineColumn.setCellFactory(value -> {
            TextFieldTableCell<DiseasesTreatments, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        remarksColumn.setCellFactory(value -> {
            TextFieldTableCell<DiseasesTreatments, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
    }

    private void attachEventsToTableColumns() {
        idColumn.setOnEditCommit(eventHandler -> {
            updateCell("id", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        livestockColumn.setOnEditCommit(eventHandler -> {
            updateCell("livestock_id", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        diseaseColumn.setOnEditCommit(eventHandler -> {
            updateCell("illness", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        dateColumn.setOnEditCommit(eventHandler -> {
            updateCell("date_ill", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        veterinarianColumn.setOnEditCommit(eventHandler -> {
            updateCell("veterinarian_name", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        medicineColumn.setOnEditCommit(eventHandler -> {
            updateCell("medicine", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        remarksColumn.setOnEditCommit(eventHandler -> {
            updateCell("remarks", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
    }

    private void updateCell(String dbColumnName, String primaryKey, String oldValue, String newValue, TableColumn.CellEditEvent event) {
        try {
            statement = connection.createStatement();
            int result = statement.executeUpdate("UPDATE `livestock_farm`.`diseases_treatment_data` SET `" + dbColumnName + "` ='" + newValue + "' WHERE (`" + primaryKey + "` =\"" + idColumn.getCellData(event.getTablePosition().getRow()) + "\");");
            populateTableWithData();
            //tableView.getSelectionModel().select(event.getTablePosition().getRow());
        } catch (MySQLSyntaxErrorException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Please refactor the data to exclude special characters.");
            alert.initModality(Modality.APPLICATION_MODAL);
            diseasesTable.getSelectionModel().select(event.getTablePosition().getRow());
            diseasesTable.refresh();
            alert.showAndWait();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void addContextMenu() {
        contextMenu = new ContextMenu();

        registerDiseaseContextMenu = new MenuItem("Register Disease", new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        registerDiseaseContextMenu.setOnAction(event -> {
            displayRegisterDiseaseView();
        });

        removeDiseaseContextMenu = new MenuItem("Delete Disease Record", new ImageView(getClass().getResource("images/buttons/remove.png").toExternalForm()));
        removeDiseaseContextMenu.setOnAction(eventHandler -> {

            DiseasesTreatments diseaseObject = diseasesTable.getSelectionModel().getSelectedItem();
            try {
                statement.execute("DELETE FROM diseases_treatment_data WHERE id = '" + diseaseObject.toString() + "';");
                populateTableWithData();
            } catch (SQLException ex) {
                ex.printStackTrace();
                displayInformationDialog();
            } catch (NullPointerException ex) {
                displayInformationDialog();
            }
        });

        refreshDiseaseContextMenu = new MenuItem("Refresh", new ImageView(getClass().getResource("images/buttons/refresh.png").toExternalForm()));
        refreshDiseaseContextMenu.setOnAction(eventHandler -> {
            populateTableWithData();
        });
        contextMenu.getItems().addAll(refreshDiseaseContextMenu, registerDiseaseContextMenu, removeDiseaseContextMenu);
        diseasesTable.setContextMenu(contextMenu);
    }

    private void displayRegisterDiseaseView() {
        try {
            //Load the AddMicrochipView Stage
            fxmlLoader = new FXMLLoader(new URL(getClass().getResource("views/Register_Disease.fxml").toExternalForm()));
            System.out.println(fxmlLoader.toString());
            Pane root = (Pane) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("Register Disease");
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.sizeToScene();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();

        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void displayInformationDialog() {
        try {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No disease record has been selected yet!", ButtonType.OK);
            alert.setTitle("Information!");
            Optional<ButtonType> result = alert.showAndWait();
            alert.setOnCloseRequest(event -> alert.close());
            if (result.get() != ButtonType.OK) {
                alert.close();
            }
        } catch (NoSuchElementException ex) {}
    }
}
