/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class RegisterDiseaseController implements Initializable {

    @FXML
    private TextField idTextField;
    @FXML
    private ComboBox<String> livestockIDComboBox;
    @FXML
    private DatePicker illnessDateDatePicker;
    @FXML
    private TextField medicineTextField;
    @FXML
    private TextField veterinarianTextField;
    @FXML
    private Label errorLabel;
    @FXML
    private TextField diseaseTextField;
    @FXML
    private TextArea remarksTextArea;
    @FXML
    private Button registerDiseaseButton;

    private Connection connection;
    private PreparedStatement statement;
    private ResultSet resultSet;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        bootstrap();
    }

    private void bootstrap() {
        registerDiseaseButton.setGraphic(new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        registerDiseaseButton.setOnAction(event -> {
//            System.out.println(persistData());
            if(persistData())
                resetFields();
        });
        illnessDateDatePicker.setValue(LocalDate.now());
        loadComboBoxWithOptions();
    }

    private boolean persistData() {
        boolean done = false;
        if (validateInputFields()) {
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.prepareStatement("INSERT INTO `livestock_farm`.`diseases_treatment_data` "
                        + "                              VALUES (?, ?, ?, ?, ?, ?, ?);");
                String ID = idTextField.getText();
                String livestockID = livestockIDComboBox.getSelectionModel().getSelectedItem().toString();
                String illness = diseaseTextField.getText();
                String dateIll = illnessDateDatePicker.getValue().toString();
                String veterinarianName = veterinarianTextField.getText();
                String medicine = medicineTextField.getText();
                String remarks = remarksTextArea.getText();
                statement.setString(1, ID);
                statement.setString(2, livestockID);
                statement.setString(3, illness);
                statement.setString(4, dateIll);
                statement.setString(5, veterinarianName);
                statement.setString(6, medicine);
                statement.setString(7, remarks);
                boolean result = statement.execute();
                if(result == false) {
                    displayOKDialog("Disease " + ID + " has been registered successfully!");
                    done = true;
                } else 
                    done = false;
                
            } catch (SQLException ex) {
                ex.printStackTrace();
                //animateLabel(errorLabel, ex.getMessage());
            } 
        }
        return done;
    }

    private boolean validateInputFields() {
        boolean everythingSet;
        if (idTextField.getText() == null || idTextField.getText() == "" || idTextField.getText().isEmpty()
            || diseaseTextField.getText() == null || diseaseTextField.getText() == "" || diseaseTextField.getText().isEmpty()
            || veterinarianTextField.getText() == null || veterinarianTextField.getText() == "" || veterinarianTextField.getText().isEmpty()
            || medicineTextField.getText() == null || medicineTextField.getText() == "" || medicineTextField.getText().isEmpty()
                || remarksTextArea.getText() == null || remarksTextArea.getText() == "" || remarksTextArea.getText().isEmpty()) {
            animateLabel(errorLabel, "Fill empty fields!");
            everythingSet = false;
            return everythingSet;
        } else {
            everythingSet = true;
        }
        return everythingSet;
    }

    private void animateLabel(Label errorlabel, String message) {
        errorLabel.setText(message);
        errorLabel.setOpacity(1.0);
        FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
        transition1.setFromValue(1.0);
        transition1.setToValue(0.0);
        transition1.play();
    }

    private void resetFields() {
        idTextField.setText(null);
        livestockIDComboBox.getSelectionModel().clearSelection();
        diseaseTextField.setText(null);
        illnessDateDatePicker.setValue(LocalDate.now());
        veterinarianTextField.setText(null);
        medicineTextField.setText(null);
        remarksTextArea.setText(null);
        remarksTextArea.setPromptText("Place your comment here");
    }

    private void displayOKDialog(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done!");
            alert.setContentText(message);
            alert.initModality(Modality.APPLICATION_MODAL);
            alert.showAndWait();
    }

    private void loadComboBoxWithOptions() {
        ObservableList<String> livestockList = FXCollections.observableArrayList();
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                Statement statement = connection.createStatement();
                resultSet = statement.executeQuery("SELECT animal_id FROM livestock_table;");
                while (resultSet.next()) {
                    livestockList.add(resultSet.getString("animal_id"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            livestockIDComboBox.setItems(livestockList);
    }
    
}
