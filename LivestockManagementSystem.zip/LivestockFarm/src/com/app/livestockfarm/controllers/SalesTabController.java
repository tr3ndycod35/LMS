/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.beans.DiseasesTreatments;
import com.app.livestockfarm.beans.Sales;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.DefaultStringConverter;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class SalesTabController implements Initializable {

    @FXML
    private ScrollPane tableScrollPane;
    @FXML
    private TableView<Sales> salesTable;
    @FXML
    private TableColumn<Sales, Integer> transactionIDColumn;
    @FXML
    private TableColumn<Sales, String> livestockColumn;
    @FXML
    private TableColumn<Sales, String> dateColumn;
    @FXML
    private TableColumn<Sales, String> customerColumn;
    @FXML
    private TableColumn<Sales, Double> priceColumn;
    @FXML
    private TableColumn<Sales, String> remarksColumn;

    // Database related fields
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    // Context Menu related fields
    private ContextMenu contextMenu;
    private MenuItem registerSaleContextMenu;
    private MenuItem removeSaleContextMenu;
    private MenuItem refreshSalesContextMenu;
    


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        salesTable.prefHeightProperty().bind(tableScrollPane.heightProperty());
        salesTable.prefWidthProperty().bind(tableScrollPane.widthProperty());
        setTableProperties();
        populateTableWithData();
    }

    private void populateTableWithData() {

        ObservableList<Sales> items = FXCollections.observableArrayList();
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM sales;");

            while (resultSet.next()) {
                int transactionID = resultSet.getInt("transaction_id");
                String livestockID = resultSet.getString("livestock_id");
                String dateSold = resultSet.getString("date_sold");
                String customer = resultSet.getString("customer");
                double price = resultSet.getDouble("price");
                String remark = resultSet.getString("remarks");
                Sales salesObject = new Sales(transactionID, livestockID, dateSold, customer, price);
                salesObject.setRemarks(remark);
                items.add(salesObject);
            }
            salesTable.setItems(items);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void setTableProperties() {
        salesTable.setEditable(true);
        configureTableColumns();
        addContextMenu();
    }

    private void configureTableColumns() {
        setCellValueFactories();
        setCellFactories();
        attachEventsToTableColumns();
    }

    private void setCellValueFactories() {
        transactionIDColumn.setCellValueFactory(new PropertyValueFactory<>("transactionID"));
        livestockColumn.setCellValueFactory(new PropertyValueFactory<>("livestock"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("dateSold"));
        customerColumn.setCellValueFactory(new PropertyValueFactory<>("customer"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        remarksColumn.setCellValueFactory(new PropertyValueFactory<>("remarks"));

    }

    private void setCellFactories() {
        transactionIDColumn.setCellFactory(value -> {
            TextFieldTableCell<Sales, Integer> cell = new TextFieldTableCell<>(new IntegerStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        livestockColumn.setCellFactory(value -> {
            ObservableList<String> livestockList = FXCollections.observableArrayList();
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.createStatement();
                resultSet = statement.executeQuery("SELECT animal_id FROM livestock_table;");
                while (resultSet.next()) {
                    livestockList.add(resultSet.getString("animal_id"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            ComboBoxTableCell<Sales, String> cell = new ComboBoxTableCell<>(livestockList);
            cell.setConverter(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        dateColumn.setCellFactory(value -> {
            DatePickerCell<Sales, String> cell = new DatePickerCell<>();
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        priceColumn.setCellFactory(value -> {
            TextFieldTableCell<Sales, Double> cell = new TextFieldTableCell<>(new DoubleStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });

        remarksColumn.setCellFactory(value -> {
            TextFieldTableCell<Sales, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
    }

    private void attachEventsToTableColumns() {
        transactionIDColumn.setOnEditCommit(eventHandler -> {
            updateCell("transaction_id", "transaction_id", eventHandler.getOldValue().toString(), eventHandler.getNewValue().toString(), eventHandler);
        });
        livestockColumn.setOnEditCommit(eventHandler -> {
            updateCell("livestock_id", "transaction_id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        
        dateColumn.setOnEditCommit(eventHandler -> {
            updateCell("date_sold", "transaction_id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        customerColumn.setOnEditCommit(eventHandler -> {
            updateCell("customer", "transaction_id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        priceColumn.setOnEditCommit(eventHandler -> {
            updateCell("price", "transaction_id", eventHandler.getOldValue().toString(), eventHandler.getNewValue().toString(), eventHandler);
        });
        remarksColumn.setOnEditCommit(eventHandler -> {
            updateCell("remarks", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
    }

    private void updateCell(String dbColumnName, String primaryKey, String oldValue, String newValue, TableColumn.CellEditEvent event) {
        try {
            statement = connection.createStatement();
            int result = statement.executeUpdate("UPDATE `livestock_farm`.`sales` SET `" + dbColumnName + "` ='" + newValue + "' WHERE (`" + primaryKey + "` =\"" + transactionIDColumn.getCellData(event.getTablePosition().getRow()) + "\");");
            populateTableWithData();
        } catch (MySQLSyntaxErrorException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Please refactor the data to exclude special characters.");
            alert.initModality(Modality.APPLICATION_MODAL);
            salesTable.getSelectionModel().select(event.getTablePosition().getRow());
            salesTable.refresh();
            alert.showAndWait();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void addContextMenu() {
        contextMenu = new ContextMenu();

        registerSaleContextMenu = new MenuItem("Register Sale", new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        registerSaleContextMenu.setOnAction(event -> {
            displayRegisterSalesView();
        });

        removeSaleContextMenu = new MenuItem("Delete Sale Record", new ImageView(getClass().getResource("images/buttons/remove.png").toExternalForm()));
        removeSaleContextMenu.setOnAction(eventHandler -> {
            
            Sales salesObject = salesTable.getSelectionModel().getSelectedItem();
            try {
                statement.execute("DELETE FROM sales WHERE transaction_id = '" + salesObject.toString() + "';");
                populateTableWithData();
            } catch (SQLException ex) {
                ex.printStackTrace();
                displayInformationDialog();
            } catch (NullPointerException ex) {
                displayInformationDialog();
            }
        });

        refreshSalesContextMenu = new MenuItem("Refresh Data", new ImageView(getClass().getResource("images/buttons/refresh.png").toExternalForm()));
        refreshSalesContextMenu.setOnAction(eventHandler -> {
            populateTableWithData();
        });
        contextMenu.getItems().addAll(refreshSalesContextMenu, registerSaleContextMenu, removeSaleContextMenu);
        salesTable.setContextMenu(contextMenu);
        
    }

    private void displayRegisterSalesView() {
        try {
            //Load the AddMicrochipView Stage
            FXMLLoader loader = new FXMLLoader(new URL(getClass().getResource("views/RegisterSales.fxml").toExternalForm()));
            Pane root = (Pane) loader.load();
            Stage stage = new Stage();
            stage.setTitle("Register Sales");
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.sizeToScene();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();

        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {

        }
    }

    private void displayInformationDialog() {
        try {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No sale record has been selected yet!", ButtonType.OK);
            alert.setTitle("Information!");
            Optional<ButtonType> result = alert.showAndWait();
            alert.setOnCloseRequest(event -> alert.close());
            if (result.get() != ButtonType.OK) {
                alert.close();
            }
        } catch (NoSuchElementException ex) {
        }
    }

}
