/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.beans.Microchip;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import com.sun.webkit.ContextMenuItem;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.DefaultStringConverter;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class MicrochipsTabController implements Initializable {

    @FXML
    private ScrollPane tableScrollPane;
    @FXML
    private TableView<Microchip> microchipsTable;
    @FXML
    private TableColumn<Microchip, String> idColumn;
    @FXML
    private TableColumn<Microchip, String> manufacturerColumn;
    @FXML
    private TableColumn<Microchip, String> dateColumn;
    private ContextMenu contextMenu;
    private MenuItem addMicrochipContextMenu;
    private MenuItem removeMicrochipContextMenu;

    // Database Related Fields
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
    private MenuItem refreshMicrochipContextMenu;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        setTableProperties();microchipsTable.prefHeightProperty().bind(tableScrollPane.heightProperty());
        microchipsTable.prefWidthProperty().bind(tableScrollPane.widthProperty());
        populateTableWithData();

        // Attach context menu to table
    }

    private void populateTableWithData() {

        ObservableList<Microchip> items = FXCollections.observableArrayList();
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM microchip_data;");

            while (resultSet.next()) {
                String microchip_id = resultSet.getString("microchip_id");
                String manufacturer = resultSet.getString("manufacturer");
                String dateImplanted = resultSet.getString("date_implanted");
                Microchip microchipObject = new Microchip(microchip_id, manufacturer, dateImplanted);
                items.add(microchipObject);
            }
            microchipsTable.setItems(items);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void setTableProperties() {
        microchipsTable.setEditable(true);
        configureTableColumns();
        addContextMenu();
    }

    private void configureTableColumns() {
        setCellValueFactories();
        setCellFactories();
        attachEventsToTableColumns();
    }

    private void setCellValueFactories() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("microchipID"));
        manufacturerColumn.setCellValueFactory(new PropertyValueFactory<>("manufacturer"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("dateImplanted"));
    }

    private void setCellFactories() {
        idColumn.setCellFactory(value -> {
            TextFieldTableCell<Microchip, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        manufacturerColumn.setCellFactory(value -> {
            TextFieldTableCell<Microchip, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        dateColumn.setCellFactory(value -> {
            DatePickerCell<Microchip, String> cell = new DatePickerCell<>();
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
    }

    private void attachEventsToTableColumns() {
        idColumn.setOnEditCommit(eventHandler -> {
            updateCell("microchip_id", "microchip_id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        manufacturerColumn.setOnEditCommit(eventHandler -> {
            updateCell("manufacturer", "microchip_id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        dateColumn.setOnEditCommit(eventHandler -> {
            updateCell("date_implanted", "microchip_id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
    }

    private void updateCell(String dbColumnName, String primaryKey, String oldValue, String newValue, TableColumn.CellEditEvent event) {
        try {
            statement = connection.createStatement();
            int result = statement.executeUpdate("UPDATE `livestock_farm`.`microchip_data` SET `" + dbColumnName + "` ='" + newValue + "' WHERE (`" + primaryKey + "` =\"" + idColumn.getCellData(event.getTablePosition().getRow()) + "\");");
            populateTableWithData();
            //tableView.getSelectionModel().select(event.getTablePosition().getRow());
        } catch (MySQLSyntaxErrorException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Please refactor the data to exclude special characters.");
            alert.initModality(Modality.APPLICATION_MODAL);
            microchipsTable.getSelectionModel().select(event.getTablePosition().getRow());
            microchipsTable.refresh();
            alert.showAndWait();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }

    private void addContextMenu() {
        contextMenu = new ContextMenu();

        addMicrochipContextMenu = new MenuItem("Add New Microchip", new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        addMicrochipContextMenu.setOnAction(event -> {
            displayAddMicrochipView();
        });

        removeMicrochipContextMenu = new MenuItem("Remove Microchip", new ImageView(getClass().getResource("images/buttons/remove.png").toExternalForm()));
        removeMicrochipContextMenu.setOnAction(eventHandler -> {

            Microchip microchipObject = microchipsTable.getSelectionModel().getSelectedItem();
            try {
                statement.execute("DELETE FROM microchip_data WHERE microchip_id = '" + microchipObject.toString() + "';");
                populateTableWithData();
            } catch (SQLException ex) {
                ex.printStackTrace();
                displayInformationDialog();
            }
        });

        refreshMicrochipContextMenu = new MenuItem("Refresh", new ImageView(getClass().getResource("images/buttons/refresh.png").toExternalForm()));
        refreshMicrochipContextMenu.setOnAction(eventHandler -> {
            populateTableWithData();
        });
        contextMenu.getItems().addAll(refreshMicrochipContextMenu, addMicrochipContextMenu, removeMicrochipContextMenu);
        microchipsTable.setContextMenu(contextMenu);
    }

    private void displayAddMicrochipView() {
        try {
            //Load the AddMicrochipView Stage
            FXMLLoader loader = new FXMLLoader(new URL(getClass().getResource("views/AddMicrochipView.fxml").toExternalForm()));
            AddMicrochipViewController controller = loader.getController();
            Pane root = (Pane) loader.load();
            Stage stage = new Stage();
            stage.setTitle("Add Microchip");
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.sizeToScene();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();

        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {

        }
    }

    private void displayInformationDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "No Microchip has been selected yet!", ButtonType.OK);
        alert.setTitle("Information!");
        Optional<ButtonType> result = alert.showAndWait();
        alert.setOnCloseRequest(event -> alert.close());
        if (result.get() != ButtonType.OK) {
            alert.close();
        }
    }
}
