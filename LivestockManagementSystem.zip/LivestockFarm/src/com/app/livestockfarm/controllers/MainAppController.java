/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

/**
 *
 * @author Cherry. Controller for the MainAppView.fxml. Necessary methods have
 * been implemented in this class. It is important to note that this class is
 * used by other controller classes in this application. It also calls
 * components or widgets from other controller classes
 */
public class MainAppController extends AnchorPane implements Initializable {

    @FXML private JFXPasswordField passwordField;
    @FXML private JFXButton loginButton;
    @FXML private ImageView infoIcon;
    @FXML private Label errorLabel;
    private MainApplication mainApp;

    public void setApplication(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    /**
     * It is called by default by the JavaFX Runtime Machine for the
     * initialization of components that are not referenced with @FXML
     * annotation.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    /**
     * This method tries to log the administrator in when he or she input the
     * password. It notifies if there is a password mismatch and request the
     * user to try again.
     */
    public void tryLogin() {
        String password = passwordField.getText();
        if (password.isEmpty()) {
            errorLabel.setText("Password must not be empty");
            errorLabel.setOpacity(1.0);
            infoIcon.setOpacity(1.0);
            animateMessage();

        } else {
            if (!mainApp.isUserLoggedIn("administrator", password)) {
                errorLabel.setText("Incorrect password, try again");
                passwordField.clear();
                errorLabel.setOpacity(1.0);
                infoIcon.setOpacity(1.0);
                animateMessage();
            }

        }
    }

    /**
     * This method basically animates the label showing error encountered when
     * logging into the application for 3 milliseconds.
     */
    public void animateMessage() {
        FadeTransition fadeTransition = new FadeTransition(Duration.millis(3000), errorLabel);
        fadeTransition.setFromValue(1.0);
        fadeTransition.setToValue(0.0);
        fadeTransition.play();

        FadeTransition fadeTransition2 = new FadeTransition(Duration.millis(3000), infoIcon);
        fadeTransition2.setFromValue(1.0);
        fadeTransition2.setToValue(0.0);
        fadeTransition2.play();   
    }
}
