/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.app.livestockfarm.beans.Customer;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.converter.DefaultStringConverter;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class CustomersTabController implements Initializable {
    
    @FXML
    private ScrollPane tableScrollPane;
    @FXML
    private TableView<Customer> customersTable;
    @FXML
    private TableColumn<Customer, String> idColumn;
    @FXML
    private TableColumn<Customer, String> firstNameColumn;
    @FXML
    private TableColumn<Customer, String> lastNameColumn;
    @FXML
    private TableColumn<Customer, String> sexColumn;
    @FXML
    private TableColumn<Customer, String> addressColumn;
    @FXML
    private TableColumn<Customer, String> phoneColumn;
    @FXML
    private TableColumn<Customer, String> emailColumn;

    // Database related fields
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    // Context Menu related fields
    private ContextMenu contextMenu;
    private MenuItem registerCustomerMenuItem;
    private MenuItem removeCustomerMenuItem;
    private MenuItem refreshCustomerMenuItem;
    private MenuItem viewCustomerPhotoMenuItem;
    private MenuItem updateCustomerPhotoMenuitem;
    private MenuItem sendEmailMenuItem;
    private MenuItem sendSMSMenuItem;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        customersTable.prefHeightProperty().bind(tableScrollPane.heightProperty());
        customersTable.prefWidthProperty().bind(tableScrollPane.widthProperty());
        setTableProperties();
        populateTableWithData();
        contextMenu.setOnShown(handler -> {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    if (customersTable.getSelectionModel().getSelectedItems().size() > 1) {
                        viewCustomerPhotoMenuItem.setDisable(true);
                        updateCustomerPhotoMenuitem.setDisable(true);
                        removeCustomerMenuItem.setDisable(true);
                    } else {
                        viewCustomerPhotoMenuItem.setDisable(false);
                        updateCustomerPhotoMenuitem.setDisable(false);
                        removeCustomerMenuItem.setDisable(false);
                    }
                }
            });
        });
    }
    
    private void populateTableWithData() {
        
        ObservableList<Customer> items = FXCollections.observableArrayList();
        try {
            connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM customers;");
            
            while (resultSet.next()) {
                String customerID = resultSet.getString("id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                String sex = resultSet.getString("sex");
                String address = resultSet.getString("address");
                String phone = resultSet.getString("phone");
                String email = resultSet.getString("email");
                Blob photo = resultSet.getBlob("photo");
                
                Customer customerObject = new Customer(customerID, firstName, lastName, sex);
                customerObject.setAddress(address);
                customerObject.setPhoneNumber(phone);
                customerObject.setEmail(email);
                customerObject.setPhoto(photo);
                items.add(customerObject);
            }
            customersTable.setItems(items);
            customersTable.getSelectionModel().select(0);
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    private void setTableProperties() {
        customersTable.setEditable(true);
        customersTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        configureTableColumns();
        addContextMenu();
    }
    
    private void configureTableColumns() {
        setCellValueFactories();
        setCellFactories();
        attachEventsToTableColumns();
    }
    
    private void setCellValueFactories() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        sexColumn.setCellValueFactory(new PropertyValueFactory<>("sex"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        
    }
    
    private void setCellFactories() {
        idColumn.setCellFactory(value -> {
            TextFieldTableCell<Customer, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        firstNameColumn.setCellFactory(value -> {
            TextFieldTableCell<Customer, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        
        lastNameColumn.setCellFactory(value -> {
            TextFieldTableCell<Customer, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        
        sexColumn.setCellFactory(value -> {
            ComboBoxTableCell<Customer, String> cell = new ComboBoxTableCell<>("Male", "Female");
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        
        addressColumn.setCellFactory(value -> {
            TextFieldTableCell<Customer, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        
        phoneColumn.setCellFactory(value -> {
            TextFieldTableCell<Customer, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        
        emailColumn.setCellFactory(value -> {
            TextFieldTableCell<Customer, String> cell = new TextFieldTableCell<>(new DefaultStringConverter());
            cell.setAlignment(Pos.CENTER);
            return cell;
        });
        
    }
    
    private void attachEventsToTableColumns() {
        idColumn.setOnEditCommit(eventHandler -> {
            updateCell("id", "id", eventHandler.getOldValue().toString(), eventHandler.getNewValue().toString(), eventHandler);
        });
        firstNameColumn.setOnEditCommit(eventHandler -> {
            updateCell("first_name", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        
        lastNameColumn.setOnEditCommit(eventHandler -> {
            updateCell("last_name", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        
        sexColumn.setOnEditCommit(eventHandler -> {
            updateCell("sex", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        
        addressColumn.setOnEditCommit(eventHandler -> {
            updateCell("address", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        
        phoneColumn.setOnEditCommit(eventHandler -> {
            updateCell("phone", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        
        emailColumn.setOnEditCommit(eventHandler -> {
            updateCell("email", "id", eventHandler.getOldValue(), eventHandler.getNewValue(), eventHandler);
        });
        
    }
    
    private void updateCell(String dbColumnName, String primaryKey, String oldValue, String newValue, TableColumn.CellEditEvent event) {
        try {
            statement = connection.createStatement();
            int result = statement.executeUpdate("UPDATE `livestock_farm`.`customers` SET `" + dbColumnName + "` ='" + newValue + "' WHERE (`" + primaryKey + "` =\"" + idColumn.getCellData(event.getTablePosition().getRow()) + "\");");
            populateTableWithData();
        } catch (MySQLSyntaxErrorException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Please refactor the data to exclude special characters.");
            alert.initModality(Modality.APPLICATION_MODAL);
            customersTable.getSelectionModel().select(event.getTablePosition().getRow());
            customersTable.refresh();
            alert.showAndWait();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    private void addContextMenu() {
        contextMenu = new ContextMenu();
        
        registerCustomerMenuItem = new MenuItem("Register Customer", new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        registerCustomerMenuItem.setOnAction(event -> {
            displayRegisterCustomerView();
        });
        
        viewCustomerPhotoMenuItem = new MenuItem("View Customer's Photo", new ImageView(getClass().getResource("images/buttons/view_user.png").toExternalForm()));
        viewCustomerPhotoMenuItem.setOnAction(event -> {
            if (customersTable.getSelectionModel().getSelectedItems().size() == 1) {
                displayCustomerPhotoView();
            } else {
            }
        });
        
        updateCustomerPhotoMenuitem = new MenuItem("Update Customer's Photo", new ImageView(getClass().getResource("images/buttons/update_user.png").toExternalForm()));
        updateCustomerPhotoMenuitem.setOnAction(event -> {
            displayUpdateCustomerPhotoView();
        });
        
        removeCustomerMenuItem = new MenuItem("Delete Customer Record", new ImageView(getClass().getResource("images/buttons/remove.png").toExternalForm()));
        removeCustomerMenuItem.setOnAction(eventHandler -> {
            
            Customer customerObject = customersTable.getSelectionModel().getSelectedItem();
            try {
                statement.execute("DELETE FROM customers WHERE id = '" + customerObject.toString() + "';");
                populateTableWithData();
            } catch (SQLException ex) {
                ex.printStackTrace();
                displayInformationDialog(ex.getMessage());
            } catch (NullPointerException ex) {
                displayInformationDialog("No customer record has been selected yet!");
            }
        });
        
        refreshCustomerMenuItem = new MenuItem("Refresh Customers", new ImageView(getClass().getResource("images/buttons/refresh.png").toExternalForm()));
        refreshCustomerMenuItem.setOnAction(eventHandler -> {
            populateTableWithData();
        });
        
        sendEmailMenuItem = new MenuItem("Send Email", new ImageView(getClass().getResource("images/buttons/email.png").toExternalForm()
        ));
        
        sendSMSMenuItem = new MenuItem("Send SMS", new ImageView(getClass().getResource("images/buttons/sms.png").toExternalForm()
        ));
        
        contextMenu.getItems().addAll(refreshCustomerMenuItem, registerCustomerMenuItem, viewCustomerPhotoMenuItem,
                updateCustomerPhotoMenuitem, removeCustomerMenuItem, sendEmailMenuItem, sendSMSMenuItem);
        
        if (customersTable.getSelectionModel().getSelectedItems().size() > 1) {
//            viewCustomerPhotoContextMenu.setDisable(true);
//            updateCustomerPhotoContextMenu.setDisable(true);
//            removeCustomerContextMenu.setDisable(true);
            System.out.println("Selected items: " + customersTable.getSelectionModel().getSelectedItems().size());
        }
        
        customersTable.setContextMenu(contextMenu);
        
    }
    
    private void displayRegisterCustomerView() {
        try {
            //Load the AddMicrochipView Stage
            FXMLLoader loader = new FXMLLoader(new URL(getClass().getResource("views/RegisterCustomer.fxml").toExternalForm()));
            Pane root = (Pane) loader.load();
            RegisterCustomerController controller = loader.getController();
            
            Stage stage = new Stage();
            stage.setTitle("Register Customer");
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.sizeToScene();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
            
            Button photoUploadButton = controller.getPhotoUploadButton();
            TextField photoTextField = controller.getPhotoTextField();
            photoUploadButton.setOnAction(value -> {
                FileChooser imageFileChooser = new FileChooser();
                imageFileChooser.setSelectedExtensionFilter(new FileChooser.ExtensionFilter("Image Files", "png", "jpeg", "jpg"));
                imageFileChooser.setTitle("Select Customer's Photo");
                try {
                    File imageFile = imageFileChooser.showOpenDialog(stage);
                    
                    if (controller.validateSelectedFile(imageFile)) {
                        photoTextField.setText(imageFile.getPath());
                    } else {
                        displayInformationDialog("No supported image file selected. Check to see if image file has an extension of .png, .jpeg, or .jpg");
                    }
                } catch (NullPointerException ex) {
                }
            });
            
        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void displayInformationDialog(String message) {
        try {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
            alert.setTitle("Information!");
            Optional<ButtonType> result = alert.showAndWait();
            alert.setOnCloseRequest(event -> alert.close());
            if (result.get() != ButtonType.OK) {
                alert.close();
            }
        } catch (NoSuchElementException ex) {
        }
    }
    
    private void displayCustomerPhotoView() {
        try {
            FXMLLoader loader = new FXMLLoader(new URL(getClass().getResource("views/CustomerPhotoView.fxml").toExternalForm()));
            Pane root = (Pane) loader.load();
            CustomerPhotoViewController controller = loader.getController();
            Customer customerObject = customersTable.getSelectionModel().getSelectedItem();
            if (customerObject.getPhoto() == null) {
                displayInformationDialog("This user does not have a photo for display.");
            } else {
                controller.loadImageOfCustomer(customerObject);
                Stage stage = new Stage();
                stage.setTitle("Customer: " + customerObject.toString());
                stage.setResizable(false);
                stage.setScene(new Scene(root));
                stage.sizeToScene();
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.show();
            }
        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            displayInformationDialog("No customer has been selected yet.");
        }
        
    }
    
    private void displayUpdateCustomerPhotoView() {
        try {
            Stage stage = new Stage();
            FXMLLoader loader = new FXMLLoader(new URL(getClass().getResource("views/UpdateCustomerPhotoView.fxml").toExternalForm()));
            Pane root = (Pane) loader.load();
            UpdateCustomerPhotoViewController controller = loader.getController();
            Customer customerObject = customersTable.getSelectionModel().getSelectedItem();
            if (customerObject.getPhoto() != null) {
                controller.loadImageOfCustomer(customerObject);
            } else {
                InputStream inputStream = getClass().getResourceAsStream("images/buttons/customer.png");
                controller.getImageView().setImage(new Image(inputStream));
            }
            controller.getUploadButton().setOnAction(value -> {
                FileChooser imageFileChooser = new FileChooser();
                imageFileChooser.setSelectedExtensionFilter(new FileChooser.ExtensionFilter("Image Files", "png", "jpeg", "jpg"));
                imageFileChooser.setTitle("Select Customer's Photo");
                try {
                    File imageFile = imageFileChooser.showOpenDialog(stage);
                    
                    if (controller.validateSelectedFile(imageFile)) {
                        controller.getUploadTextField().setText(imageFile.getPath());
                        controller.getImageView().setImage(new Image(new FileInputStream(imageFile)));
                    } else {
                        displayInformationDialog("No supported image file selected. Check to see if image file has an extension of .png, .jpeg, or .jpg");
                    }
                } catch (NullPointerException ex) {
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                }
            });
            
            controller.getUpdateButton().setOnAction(value -> {
                if (controller.updateCustomerPhoto(customerObject) == false) {
                    displayInformationDialog("Photo has been updated successfully");
                    populateTableWithData();
                    stage.close();
                }
                
            });
            
            stage.setTitle("Customer: " + customerObject.toString());
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.sizeToScene();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
            
        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (NullPointerException ex) {
            displayInformationDialog("No customer has been selected yet.");

        }
        
    }
    
}
