/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.controllers;

import com.app.livestockfarm.MainApplication;
import com.mysql.jdbc.MysqlDataTruncation;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Cherry
 */
public class RegisterCustomerController implements Initializable {

    @FXML
    private Label errorLabel;
    @FXML
    private TextField customerIDTextField;
    @FXML
    private TextField firstNameTextField;
    @FXML
    private TextField lastNameTextField;
    @FXML
    private ComboBox<String> sexComboBox;
    @FXML
    private TextField addressTextField;
    @FXML
    private TextField phoneTextField;
    @FXML
    private TextField emailAddressTextField;
    @FXML
    private TextField photoTextField;
    @FXML
    private Button photoUploadButton;
    @FXML
    private Button registerCustomerButton;

    private Connection connection;
    private PreparedStatement statement;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        bootstrap();
    }

    private void bootstrap() {
        registerCustomerButton.setGraphic(new ImageView(getClass().getResource("images/buttons/add.png").toExternalForm()));
        registerCustomerButton.setOnAction(event -> {
            if (persistData()) {
                resetFields();
            }
        });
        sexComboBox.setItems(FXCollections.observableArrayList("Male", "Female"));
        sexComboBox.selectionModelProperty().get().select(0);
        photoUploadButton.setGraphic(new ImageView(getClass().getResource("images/buttons/upload.png").toExternalForm()));

    }

    public Button getPhotoUploadButton() {
        return photoUploadButton;
    }

    public TextField getPhotoTextField() {
        return photoTextField;
    }

    private boolean persistData() {
        boolean done = false;
        if (validateInputFields()) {
            try {
                connection = DriverManager.getConnection(MainApplication.DATABASE_URL, MainApplication.USER, MainApplication.PASS);
                statement = connection.prepareStatement("INSERT INTO `livestock_farm`.`customers` "
                        + "                              VALUES (?, ?, ?, ?, ?, ?, ?, ?);");
                String id = customerIDTextField.getText();
                String firstName = firstNameTextField.getText();
                String lastName = lastNameTextField.getText();
                String sex = sexComboBox.getSelectionModel().getSelectedItem();
                String address = addressTextField.getText();
                String phone = phoneTextField.getText();
                String email = emailAddressTextField.getText();
                String photoFileName = photoTextField.getText();
                File imageFile = new File(photoFileName);
                FileInputStream fis = new FileInputStream(imageFile);

                statement.setString(1, id);
                statement.setString(2, firstName);
                statement.setString(3, lastName);
                statement.setString(4, sex);
                statement.setString(5, address);
                statement.setString(6, phone);
                statement.setString(7, email);
                statement.setBinaryStream(8, fis, (int) imageFile.length());

                boolean result = statement.execute();
                if (result == false) {
                    displayOKDialog("Customer " + id + " has been registered successfully!");
                    done = true;
                } else {
                    done = false;
                }

            } catch (MysqlDataTruncation ex) {
                animateLabel(errorLabel, "Select an image with a smaller size.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                //animateLabel(errorLabel, ex.getMessage());
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return done;
    }

    private boolean validateInputFields() {
        boolean everythingSet;
        if (customerIDTextField.getText() == null || customerIDTextField.getText() == "" || customerIDTextField.getText().isEmpty()
                || firstNameTextField.getText() == null || firstNameTextField.getText() == "" || firstNameTextField.getText().isEmpty()
                || lastNameTextField.getText() == null || lastNameTextField.getText() == "" || lastNameTextField.getText().isEmpty()
                || addressTextField.getText() == null || addressTextField.getText() == "" || addressTextField.getText().isEmpty()
                || phoneTextField.getText() == null || phoneTextField.getText() == "" || phoneTextField.getText().isEmpty()
                || emailAddressTextField.getText() == null || emailAddressTextField.getText() == "" || emailAddressTextField.getText().isEmpty()) {
            animateLabel(errorLabel, "Fill empty fields!");
            everythingSet = false;
            return everythingSet;
        } else {
            everythingSet = true;
        }
        return everythingSet;
    }

    private void animateLabel(Label errorlabel, String message) {
        errorLabel.setText(message);
        errorLabel.setOpacity(1.0);
        FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
        transition1.setFromValue(1.0);
        transition1.setToValue(0.0);
        transition1.play();
    }

    private void resetFields() {
        customerIDTextField.setText(null);
        firstNameTextField.setText(null);
        lastNameTextField.setText(null);
        sexComboBox.getSelectionModel().select(0);
        addressTextField.setText(null);
        phoneTextField.setText(null);
        emailAddressTextField.setText(null);
        photoTextField.setText(null);
    }

    private void displayOKDialog(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done!");
        alert.setContentText(message);
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.showAndWait();
    }

    protected boolean validateSelectedFile(File file) {
        boolean validImageFile = false;
        if (file.isFile()) {
            if (file.getName().endsWith(".png") || file.getName().endsWith(".jpeg") || file.getName().endsWith(".jpg")) {
                validImageFile = true;
                return validImageFile;
            }
        } else {
            validImageFile = false;
            return validImageFile;
        }
        return validImageFile;
    }

}
