/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.beans;

import java.util.Date;

/**
 *
 * @author Cherry
 */
public class Sales {
    
    private int transactionID;
    private String livestock;
    private String dateSold;
    private String customer;
    private double price;
    private String remarks;
    
    public Sales(int id, String livestock, String date, String customer, double price){
        this.transactionID = id;
        this.livestock = livestock;
        this.dateSold = date;
        this.customer = customer;
        this.price = price;
    }

    public int getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(int transactionID) {
        this.transactionID = transactionID;
    }
    
    
    public String getLivestock() {
        return livestock;
    }

    public void setLivestock(String livestock) {
        this.livestock = livestock;
    }

    public String getDateSold() {
        return dateSold;
    }

    public void setDateSold(String dateSold) {
        this.dateSold = dateSold;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }


    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return String.valueOf(transactionID);
    }
      
}
