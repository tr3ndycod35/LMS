/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.beans;
/**
 *
 * @author Cherry
 */
public class DiseasesTreatments {
    private String ID;
    private String livestock;
    private String illness;
    private String dateIll;
    private String veterinarianName;
    private String medicine;
    private String remarks;

    public DiseasesTreatments(String ID, String livestock, String illness, String dateIll, String veterinarianName, String medicine, String remarks) {
        this.ID = ID;
        this.livestock = livestock;
        this.illness = illness;
        this.dateIll = dateIll;
        this.veterinarianName = veterinarianName;
        this.medicine = medicine;
        this.remarks = remarks;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getLivestock() {
        return livestock;
    }

    public void setLivestock(String livestock) {
        this.livestock = livestock;
    }

    public String getDateIll() {
        return dateIll;
    }

    public void setDateIll(String dateIll) {
        this.dateIll = dateIll;
    }

    public String getIllness() {
        return illness;
    }

    public void setIllness(String Illness) {
        this.illness = Illness;
    }

    public String getVeterinarianName() {
        return veterinarianName;
    }

    public void setVeterinarianName(String veterinarianName) {
        this.veterinarianName = veterinarianName;
    }

    public String getMedicine() {
        return medicine;
    }

    public void setMedicine(String medicine) {
        this.medicine = medicine;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    public String toString() {
        return this.ID;
    }
}
