/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.beans;

import java.sql.Blob;

/**
 *
 * @author Cherry
 */
public class Customer {
    private String customerID;
    private String firstName;
    private String lastName;
    private String sex;
    private String address;
    private String phoneNumber;
    private String email;
    private Blob photo;
    
    public Customer(String id, String firstName, String lastName, String sex) {
        this.customerID = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.sex = sex;
    }
    
    public void setCustomerID(String id) {
        this.customerID = id;
    }
    
    public String getCustomerID() throws NullPointerException {
        return this.customerID;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getFirstName() throws NullPointerException {
        return this.firstName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getLastName() throws NullPointerException {
        return this.lastName;
    }
    
    public void setSex(String Sex) {
        this.sex = sex;
    }
    
    public String getSex() throws NullPointerException {
        return this.sex;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getAddress() throws NullPointerException {
        return this.address;
    }
    
    public void setPhoneNumber(String phone) {
        this.phoneNumber = phone;
    }
    
    public String getPhoneNumber() {
        return this.phoneNumber;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getEmail() throws NullPointerException {
        return this.email;
    }
    
    public void setPhoto(Blob photo) {
        this.photo = photo;
    }
    
    public Blob getPhoto()  {
        return this.photo;
    }
    
    public String toString() {
        return this.customerID;
    }
}
