/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.beans;

import java.util.Date;

/**
 *
 * @author Cherry
 */
public class RecentActivity {
    private int id;
    private String action;
    private Date time;
    
    public RecentActivity(String action, Date time) {
        this.action = action;
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "RecentActivity{" + "id=" + id + ", action=" + action + ", time=" + time + '}';
    }
    
    
}
