/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.beans;

/**
 *
 * @author Cherry
 */
public class Microchip {
    private String microchipID;
    private String dateImplanted;
    private String manufacturer;
    
    public Microchip() {
        this(null, null, null);
    }
    
    public Microchip(String microchipID, String manufacturer, String dateImplanted){
        this.microchipID = microchipID;
        this.manufacturer = manufacturer;
        this.dateImplanted = dateImplanted;
    }
    
    public void setMicrochipID(String microchipID) {
        this.microchipID = microchipID;
    }
    
    public String getMicrochipID(){
        return this.microchipID;
    }
    
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
    
    public String getManufacturer() {
        return this.manufacturer;
    }

    public String getDateImplanted() {
        return dateImplanted;
    }

    public void setDateImplanted(String dateImplanted) {
        this.dateImplanted = dateImplanted;
    }
    
    @Override
    public String toString() {
       return this.microchipID;
    }
    
}
