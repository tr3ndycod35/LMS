/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.beans;

/**
 *
 * @author Cherry
 */
public class Purchases {

    private String purchaseID;
    private String type;
    private String productDescription;
    private String datePurchased;
    private String vendor;
    private double price;

    public Purchases(String purchaseID, String type, String productDescription, String datePurchased, String vendor, double price) {
        this.purchaseID = purchaseID;
        this.type = type;
        this.productDescription = productDescription;
        this.datePurchased = datePurchased;
        this.vendor = vendor;
        this.price = price;
    }

    
    public String getPurchaseID() {
        return purchaseID;
    }

    public void setPurchaseID(String purchaseID) {
        this.purchaseID = purchaseID;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getDatePurchased() {
        return datePurchased;
    }

    public void setDatePurchased(String datePurchased) {
        this.datePurchased = datePurchased;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    @Override
    public String toString() {
        return this.purchaseID;
    }

}
