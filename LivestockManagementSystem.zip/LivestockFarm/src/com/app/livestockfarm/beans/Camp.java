/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.beans;

/**
 *
 * @author Cherry
 */
public class Camp {

    private String campID;
    private String dateCreated;
    private int capacity;


    public Camp(String campID, String dateCreated, int capacity) {
        this.campID = campID;
        this.dateCreated = dateCreated;
        this.capacity = capacity;
    }

    public String getCampID() {
        return campID;
    }

    public void setCampID(String campID) {
        this.campID = campID;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    
    @Override
    public String toString() {
        return this.campID;
    }
}
