/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm.beans;



/**
 *
 * @author Cherry
 */
public class Livestock {

    private String animalID;
    private String animalType;
    private String source;
    private String birthDate;
    private String sex;
    private double weight;
    private String breed;
    private String color;
    private byte[] image;
    private String sireID;
    private String damID;
    private String notes;
    private String microchipInfo;
    private double bookValue;
    private double marketValue;
    private String camp;

    public Livestock(String animalID, String animalType, String source, String sex, double weight) {
        this.animalID = animalID;
        this.animalType = animalType;
        this.source = source;
        this.sex = sex;
        this.weight = weight;
    }

    public void setAnimalID(String animalID) {
        this.animalID = animalID;
    }

    public String getAnimalID() {
        return this.animalID;
    }

    public void setAnimalType(String animalType) {
        this.animalType = animalType;
    }

    public String getAnimalType() {
        return this.animalType;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getSource() {
        return source;
    }

    public String getBirthDate() throws NullPointerException {
        return this.birthDate;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSex() {
        return this.sex;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getBreed() {
        return this.breed;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getColor() {
        return this.color;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public byte[] getImage() {
        return this.image;
    }

    public void setSireID(String sireID) {
        this.sireID = sireID;
    }

    public String getSireID() {
        return this.sireID;
    }

    public void setDamID(String damID) {
        this.damID = damID;
    }

    public String getDamID() {
        return this.damID;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getNotes() {
        return this.notes;
    }

    public void setMicrochipInfo(String microchip) {
        this.microchipInfo = microchip;
    }

    public String getMicrochipInfo() {
        return this.microchipInfo;
    }

    public void setBookValue(double bookValue) {
        this.bookValue = bookValue;
    }

    public double getBookValue() {
        return this.bookValue;
    }

    public void setMarketValue(double marketValue) {
        this.marketValue = marketValue;
    }

    public double getMarketValue() {
        return this.marketValue;
    }

    public void setCamp(String camp) {
        this.camp = camp;
    }

    public String getCamp() {
        return this.camp;
    }

    @Override
    public String toString() {
        return this.animalID;
    }
}
