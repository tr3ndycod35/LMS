/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.livestockfarm;

import javafx.animation.FadeTransition;
import javafx.scene.control.Label;
import javafx.util.Duration;

/**
 *
 * @author Cherry
 */
public class Validator {

//    public static double validateNumber(String value, Label errorLabel) {
//        double weight = 0;
//        if (value.isEmpty()) {
//            return 0;
//        }
//        try {
//            weight = Double.valueOf(value);
//        } catch (NumberFormatException numberFormatException) {
//            errorLabel.setText("Value of weight must be number");
//            FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
//            transition1.setFromValue(1.0);
//            transition1.setToValue(0.0);
//            transition1.play();
//
//        }
//        return weight;
//    }
    
//    public static double validateMarketValue(String value, Label errorLabel) {
//        double price = 0;
//        if (value.isEmpty()) {
//            return 0;
//        }
//        try {
//            price = Double.valueOf(value);
//        } catch (NumberFormatException numberFormatException) {
//            errorLabel.setText("Market value must be number");
//            FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
//            transition1.setFromValue(1.0);
//            transition1.setToValue(0.0);
//            transition1.play();
//
//        }
//        return price;
//    }
    
    public static double validateNumber(String name, String value, Label errorLabel) {
        double price = 0;
        if (value == null) {
            return 0;
        }
        try {
            price = Double.valueOf(value);
        } catch (NumberFormatException numberFormatException) {
            errorLabel.setText(name + " must be number");
            FadeTransition transition1 = new FadeTransition(Duration.seconds(3), errorLabel);
            transition1.setFromValue(1.0);
            transition1.setToValue(0.0);
            transition1.play();

        }
        return price;
    }
    
}
